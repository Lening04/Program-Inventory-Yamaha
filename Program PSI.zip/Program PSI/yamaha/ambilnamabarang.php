<?php 
include "koneksi1.php";
$ID_BARANG = $_GET['q'];
if($ID_BARANG){
    $query = mysql_query("select * from barang where ID_BARANG='$ID_BARANG'");
        while($d = mysql_fetch_array($query)){
            echo $d['NAMA_BARANG'];
    }
}
?>
