<?php 
include "koneksi1.php";
$ID_BARANG = $_GET['q'];
if($ID_BARANG){
    $query = mysql_query("select * from harga_barang where ID_BARANG='$ID_BARANG' AND status='0'");
        while($d = mysql_fetch_array($query)){
            echo $d['HARGA_BELI'];
    }
}
?>