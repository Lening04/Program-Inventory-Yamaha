<?php
session_start(); 
$tes=$_SESSION['level'];
	
	if(!isset($_SESSION['username'])OR($_SESSION['password']))
		{
		echo "<meta http-equiv=\"refresh\" content=\"1;url=home.php\">";
		}		
	if ($_SESSION['level'] == "OTO-003")
   		{   
		echo "<p>Selamat Datang ".$_SESSION['username']."</p>";

include ("koneksi1.php");
include("kode_auto.php");
$option = $_REQUEST["option"];
$find = $_REQUEST["find"];
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Yamaha Kebon Agung Motor</title>
<meta name="keywords" content="blue, marble, design, theme, web, free templates, website templates, CSS, HTML" />
<meta name="description" content="Blue Marble Theme is a free website template provided by templatemo.com" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />


<link type="text/css" href="js/css/le-frog/jquery-ui-1.8.18.custom.css" rel="stylesheet" />
<script type="text/javascript" src="js/jquery-1.7.1.min.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.8.18.custom.min.js"></script>
<script type="text/javascript">
$(function(){
			// Dialog			
				$('#dialog').dialog({
					autoOpen: false,
					width: 390,
					buttons: {
						"Ok": function(){
		    					$("#penjualan").submit();
		  						},
						"Cancel": function() { 
							$(this).dialog("close"); 
						} 
					}
				});			
				// Dialog Link
				$('#dialog_link').click(function(){
					$('#dialog').dialog('open');
					return false;
				});			
				//hover states on the static widgets
				$('#dialog_link, ul#icons li').hover(
					function() { $(this).addClass('ui-state-hover'); }, 
					function() { $(this).removeClass('ui-state-hover'); }
				);
				});
</script>


<style type="text/css">
<!--
.style2 {	color: #FFFFFF;
	font-weight: bold;
}
.style3 {font-size: 16px}
.style18 {font-size: 13px}
.style22 {font-size: 14px; font-weight: bold; }
.style23 {font-weight: bold; font-size: 16px; color: #000000; }
.style24 {font-size: 14px}
-->
</style>

<style>

/* CSS UNTUK JENDELA POPUP */
#popup_full{
 position:fixed;
 z-index:1000;
 top:0;
 left:0;
 right:0;
 bottom:0;
 background:#999999;
 filter:alpha(opacity=70);
 opacity:0.7;
}
#popup_centering {
 position:fixed;
 z-index:1001;
 top:0;
 left:0;
 right:0;
 bottom:0;
}
#popup_wraper{
 margin:0 auto;
 z-index:1002;
 position:relative;
 padding-bottom:25px;
}
#popup_frame{
 position:relative;
 margin:0;
 padding:0;
 border:2px #000 solid;
 border-top:none;
 background:#E4FFDF;
}
#popup_header{
 height:25px;
 width:100%;
 position:relative;
 border:2px #000 solid;
 border-bottom:none;
 text-align:left;
 background:#009900;
 font-weight:600;
 color:#fff;
}
.popup_title{
 float:left;
 padding-left:10px;
 line-height:25px;
}
.popup_close{
 float:right;
 padding:0 10px 0 10px;
 background:#A60004;
 color:#FFFFFF;
 line-height:25px;
 cursor:pointer;
}
/* ======================= */

</style>

</head>
<body>

<!-- MULAI AREA POPUP -->
<div id="popup_full"></div>
<table width="100%" height="100%" border="0" align="center"
cellpadding="0" cellspacing="0" id="popup_centering"></table>
<!-- AKHRIR AREA POPUP -->



<div id="templatemo_header_wrapper">
	<div id="templatemo_header">
    
    	<div id="site_title">
            <a href="http://www.templatemo.com"><span><strong>Part _and_ Accessories</strong></span></a>        </div> 
<!-- end of site_title -->
<div id="social_box"> <a href="http://www.stumbleupon.com/" target="_blank"><img src="images/stumbleupon.png" alt="stumbleupon" /></a> <a href="http://digg.com/" target="_blank"><img src="images/digg.png" alt="digg" /></a> <a href="http://www.facebook.com/" target="_blank"><img src="images/facebook.png" alt="facebook" /></a> <a href="https://twitter.com/" target="_blank"><img src="images/twitter.png" alt="twitter" /></a> <a href="http://feeds.feedburner.com/BasicBlogTips" target="_blank"><img src="images/feed.png" alt="feed" /></a> </div>
<div id="templatemo_menu">
            <ul>
                <li><a href="home.php">Home</a></li>
            </ul>    	
      </div> <!-- end of templatemo_menu -->
    
    </div> <!-- end of header -->
</div> <!-- end of header wrapper -->

<div id="templatemo_main_wrapper">
	<div id="templatemo_main">
    
   	  <div id="templatemo_content">
<div class="last_content_box">
        <h2><strong>Display Retur</strong> <strong>Suku cadang</strong></h2>
        <style type="text/css">
<!--
a:link {
	text-decoration: none;
	color: ##4f7eff;
}
a:visited {
	text-decoration: none;
	color: ##4f7eff;
}
a:hover {
	text-decoration: none;
}
a:active {
	text-decoration: none;
}
.style1 {font-weight: bold}
.style2 {color: #FF00FF}
-->
</style>


<!-- ui-dialog -->
		<div id="dialog" title="Jenis Customer">
		<form action="penjualan.php" method="get" id="penjualan" name="penjualan">
        <table width="351" border="0" align="center">
  <tr>
    <td width="170" align="left"><strong>Jenis Customer</strong></td>
    <td width="171"><label>
      <select name="jenis_customer" id="jenis_customer">
      <option>-- Jenis Customer --</option>
        <option value="0">yamaha</option>
        <option value="1">individu</option>
            </select>
    </label></td>
  </tr>
</table>
 		</form>
		</div>


 <h3 align="center" class="style2"><a href="display_retur.php"><img src="images/table.png" alt="" width="100" height="107" /></a><a href="display_retur.php?option=cari"><img src="images/search data.png" width="105" height="105" /></a>  </h3>
<h3 align="center" class="style2">
</h3>


<?php		   
if($option =="")
{
$batasan=5;
$angka=$_GET['angka'];
$batas=$_GET[batas];
$halaman=$_GET['halaman'];
if(empty($halaman)){
	$posisi=0;
	$halaman=1;
}
else{
	$posisi = ($halaman-1)*$batas;
}
?>

<form action="<?php $file ?>" method="get">
<?php
echo"<input type=hidden name=halaman value=$halaman>
	 Tentukan Tampilan Data Per Halaman :";?>
	<select name=batas onchange="this.form.submit()">
<?php
//echo "<option value=$angka>";
for($j=1;$j<=6;$j++){
	$angka=$batasan*$j;?>	
    <?php
	if($batas==$angka)
		echo "<option value=$angka selected>$angka</option>";
		else
			echo "<option value=$angka>$angka</option>";}?>
</select>
</form>
</br>
<?php
if(empty($batas)){
	$batas=$batasan;}
else{
	$batas=$batas;
}		   
?>


<table width="581" border="1" align="center"  cellpadding="0" cellspacing="0">
<tr>
	<td width="77" bgcolor="#FFFF66"> <div align="center" class="style23">No</div> </td>
	<td width="125" bgcolor="#FFFF66"> <div align="center" class="style23">No Retur</div> </td>
	<td width="369" bgcolor="#FFFF66"> <div align="center" class="style23">Status</div> </td>
</tr>
<?php 
if(isset($find))
	{
	$sql2= "select *  from retur where NO_RETUR like '%$find%' ";
	}
else
	{
	$sql2= "select * from retur ORDER BY NO_RETUR DESC LIMIT $posisi,$batas";
	}

$hasil = mysql_query($sql2);
$i=0+$posisi;

while($row=mysql_fetch_array($hasil)){
$i++;
?>

<tr>
	<td height="30" class="style18"> <div align="center" class="style24 style24"><?php echo $i; ?></div></td>
	<td class="style18"> <div align="center" class="style24 style24"><a href="#" onclick="popmeup('display_popup.php?NO_RETUR=<?php echo $row['NO_RETUR'];?>','800px',
'400px','Display Retur');" style="text-decoration:none"><?php echo $row['NO_RETUR']; ?></a></div></td>
	<td class="style18"
    <?php  if($row['STATUS_RETUR']==0) { ?>style="color:#FFFF00" <?php } 
    else if($row['STATUS_RETUR']==1) { ?>style="color:#33FF00" <?php }?>> <div align="center" class="style24 style24">
	<?php if($row['STATUS_RETUR']==0){echo 'BARANG PENGGANTI RETUR BELUM ADA';} 
	else if($row['STATUS_RETUR']==1) {echo 'BARANG PENGGANTI RETUR SUDAH DITERIMA';}?> 
    </div></td>
      <td width="0"></td>	
</tr>
<?php 
}
?>


</table>
<?php 
echo "<br>Halaman : ";
$tampil2 = mysql_query("select * from retur");
$jmldata = mysql_num_rows ($tampil2);
$jmlhalaman = ceil($jmldata/$batas);
$file = "display_retur.php";
for($k=1;$k<=$jmlhalaman;$k++)
if($k != $halaman){
	echo "<a href=$file?halaman=$k&batas=$batas>$k</a> | ";
}
else{
	echo "<b>$k</b> | ";
	}
echo "<p>Total retur : <b>$jmldata</b> retur</p>";

}
?>


<?php
if($option=="cari"){
?>
<form id="form1" name="form1" method="post" action="display_retur.php">
<table width="435" border="0" align="center">
  <tr>
    <td><span class="style22">No Retur</span></td>
    <td><label>
      <input type="text" name="find" id="find" />
    </label></td>
    </tr>
  <tr>
    <td width="188">&nbsp;</td>
    <td width="237"><input type="submit" name="button2" id="button2" value="Search" /> <label></label></td>
    </tr>
</table>
</form>

<?php 
}
?>




        <div class="service_box"></div>
                
      </div>
   	  </div> <!-- end of content -->
        
        <div id="templatemo_sidebar">
        	<div class="sidebar_box"><img src="images/templatemo_ads.png" width="250" height="250" /></div>  
        	
            <div class="sidebar_box">
              <ul class="tmo_list">
                <p>
                  <?php
		include "cek.php";
		session_start();
			
						
if ($_SESSION['level'] == "OTO-001")		
{
     
      echo "<p>Selamat Datang ".$_SESSION['username']."</p>";?>
                </p>
                <p>&nbsp; </p>
                <blockquote>
                  <p class="style3"><strong><a href="ubah_password.php">Ubah Password</a></strong></p>
                  <p class="style3">&nbsp;</p>
                  <p class="style3"><strong>Master</strong></p>
                </blockquote>
                <ul class="MenuBarVertical">
                  <ul>
                    <li><a href="karyawanInput.php">karyawan</a></li>
                    <li><a href="baranginput.php">barang</a></li>
                    <li><a href="tipeBarang_input.php">tipe barang</a></li>
                    <li><a href="hargaBarangInput.php">harga barang</a></li>
                    <li><a href="otoritasinput.php">otoritas</a></li>
                  </ul>
                </ul>
                <blockquote>
                  <p class="style3">&nbsp;</p>
                </blockquote>
                <h4><a href="logout.php" class="style2"><strong>Logout</strong></a></h4>
                <p>
                  <?php		
}



else if ($_SESSION['level'] == "OTO-002")
  	 {
     
      echo "<p>Selamat Datang ".$_SESSION['username']."</p>";?>
                </p>
                <p>&nbsp; </p>
                <blockquote>
                  <p class="style3"><strong><a href="ubah_password.php">Ubah Password</a></strong></p>
                  <p class="style3">&nbsp;</p>
                  <p class="style3"><strong>Persetujuan</strong></p>
                </blockquote>
                <ul>
                  <li><a href="acc_pemesanan.php">ACC pemesanan</a></li>
                </ul>
                <blockquote>
                  <p class="style3">&nbsp;</p>
                  <p class="style3"><strong>Laporan</strong></p>
                </blockquote>
                <ul>
                  <ul>
                    <li><a href="lap_pemesanan.php">pemesanan</a></li>
                    <li><a href="lap_penerimaan.php">penerimaan</a></li>
                    <li><a href="lap_retur.php">retur</a></li>
                    <li><a href="lap_pnr_retur.php">penerimaan retur</a></li>
                    <li><a href="lap_penjualan.php">penjualan</a>
                      <blockquote>
                        <p>&nbsp;</p>
                      </blockquote>
                    </li>
                  </ul>
                </ul>
                <h4><a href="logout.php" class="style2"><strong> Logout</strong></a></h4>
                <p>
                  <?php
		 
}



else if ($_SESSION['level'] == "OTO-003")
{
     
      echo "<p>Selamat Datang ".$_SESSION['username']."</p>";?>
                </p>
                <blockquote>
                  <blockquote>&nbsp;</blockquote>
                  <p class="style3"><strong><a href="ubah_password.php">Ubah Password</a></strong></p>
                  <p class="style3">&nbsp;</p>
                  <p class="style3"><strong>Transaksi</strong></p>
                  <ul>
                     <li><a href="history_pemesanan.php">history pemesanan</a></li>
        <li><a href="pemesanan.php">pemesanan</a></li>
        <li><a href="penerimaan.php">penerimaan</a></li>
        <li><a href="display_retur.php">display retur</a></li>
        <li><a href="rtr_penerimaan.php">penerimaan retur</a></li>
                  </ul>
                  <p class="style3">&nbsp;</p>
                </blockquote>
                <h4><a href="logout.php" class="style2"><strong>Logout</strong></a></h4>
                <p>
                  <?php
	   
}
	
	
	
?>
                </p>
              </ul>
          </div>
      </div>
      <div class="cleaner"></div>
    </div> <!-- end of main -->
</div> <!-- end of main wrapper -->

<div id="templatemo_footer_wrapper">
	<div id="templatemo_footer">    
        <p><center><strong>Copyright © 2016</strong><strong><br />
        Yamaha Kebon Agung Motor</strong><strong><br />
		</strong></center></p>
    </div>
    
	<div class="cleaner"></div>
</div> <!-- end of templatemo_footer -->



<script>

// SEMBUNYIKAN ELEMENT DENGAN ID TERSEBUT DI BAWAH
$("#popup_full").hide();
$("#popup_centering").hide();

// FUNGSI MENUTUP POPUP
function closeme() {
 $("#popup_full").hide();
 $("#popup_centering").hide();
 document.getElementById('popup_centering').innerHTML='';
 };

//FUNGSI MEMBUKA POPUP 
function popmeup(u,w,h,t){
 $("#popup_full").show();       // TAMPILKAN BACKGROUND
 $("#popup_centering").show();  // TAMPILKAN CONTAINER

var a = '<tr><td align="center" valign="middle">';
var b = '<div id="popup_wraper" style="width:'+w+'; height:'+h+';">';
var c = '<div id="popup_header"><span class="popup_title">'+t+'</span>';
var d = '<span class="popup_close" onclick="closeme();">Close</span></div>';
var e = '<iframe width="100%" height="100%" frameborder="0" src="'+u+'" ';
var f = 'scrolling="auto" id="popup_frame"></iframe></div></td></tr>';
var showme = a+b+c+d+e+f;

document.getElementById('popup_centering').innerHTML=showme;
};

</script>

</body>
</html>



<?php 
} 	  				
	else 
   		{
      		echo "<script>alert(' ANDA TIDAK MEMILIKI HAK AKSES');</script>";
	  		echo "<meta http-equiv=\"refresh\" content=\"1;url=home.php\">";
		}
?>