<?php
session_start();
include"koneksi1.php";
include("FusionCharts.php");
include("FC_Colors.php");
?>


<HTML>
   <HEAD>
   <link rel="shortcut icon" href="index/untitled.bmp" type="image/x-icon" />
     <link rel="stylesheet" href= "../mburbee/Contents/Style.css" type="text/css"/>
      <SCRIPT LANGUAGE="Javascript" SRC="fusioncharts/FusionCharts/FusionCharts.js"></SCRIPT>
      <style type="text/css">
<!--
.style2 {
	font-family: Arial, Helvetica, sans-serif;
	font-size: x-small;
}
-->
      </style>
</HEAD>
   <BODY>
   <p>
   
   
<?php  
$tanggal = $_REQUEST["tanggal"];
$bulan = $_REQUEST["bulan"];
$tahun = $_REQUEST["tahun"];
$tanggal1 = $_REQUEST["tanggal1"];
$bulan1 = $_REQUEST["bulan1"];
$tahun1 = $_REQUEST["tahun1"];
		
//menampilkan judul
$strXML = "<graph caption='GRAFIK PEMESANAN SUKU CADANG PERIODE $tanggal-$bulan-$tahun SAMPAI $tanggal1-$bulan1-$tahun1' xAxisName='Barang' yAxisName='Jumlah Pemesanan' decimalPrecision='0' showNames='1' numberSuffix=' ' pieSliceDepth='30' formatNumberScale='0'>";
  
$strQuery = mysql_query("SELECT b.ID_BARANG 
FROM pemesanan_barang a, detail_pemesanan b, karyawan c, barang d
WHERE a.NO_PEMESANAN = b.NO_PEMESANAN
AND a.NIK = c.NIK
AND b.ID_BARANG = d.ID_BARANG LIKE '$tahun-$bulan-$tanggal%'
AND a.TGL_PEMESANAN >= '$tahun-$bulan-$tanggal'
AND a.TGL_PEMESANAN <= '$tahun1-$bulan1-$tanggal1'
GROUP BY b.ID_BARANG");
   
   
//mencari jumla pemesanan per barang
while($ors = mysql_fetch_array($strQuery)) {
$jmlh=0;   	  
$b=$ors[ID_BARANG];
$nm = mysql_query("SELECT * FROM barang WHERE ID_BARANG='$b'");
$nama=mysql_fetch_array($nm);
$nama2=$nama['NAMA_BARANG'];
	  
$jum = mysql_query("SELECT b.* FROM pemesanan_barang a, detail_pemesanan b WHERE a.NO_PEMESANAN=b.NO_PEMESANAN AND b.ID_BARANG='$b' 
AND (a.TGL_PEMESANAN >= '$tahun-$bulan-$tanggal' 
and a.TGL_PEMESANAN <='$tahun1-$bulan1-$tanggal1')");

while($jumlah = mysql_fetch_array($jum)){
$jmlh=$jmlh+$jumlah['JUMLAH_PEMESANAN'];
}

$strXML .= "<set name='" . $nama2 . "' value='" . $jmlh . "' color='" .getFCColor() . "'/>";
}
  
$strXML .= "</graph>";
echo renderChart("fusioncharts/FusionCharts/FCF_Column3D.swf", "", $strXML, "FactorySum", 1250, 550);
?>


   </p>
   <p>&nbsp;</p>
   <?php echo $tanggal = $_REQUEST["tanggal"]; ?>
   <p>&nbsp;</p>
     </div>
   </div>
   </BODY>
</HTML>