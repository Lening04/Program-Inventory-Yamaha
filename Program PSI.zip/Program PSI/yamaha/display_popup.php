<?php
ob_start();
session_start(); 
$tes=$_SESSION['level'];
	if(!isset($_SESSION['username'])OR($_SESSION['password']))
		{
		echo "<meta http-equiv=\"refresh\" content=\"1;url=home.php\">";
		}		
	if ($_SESSION['level'] == "OTO-003")
   		{   
	

include ("koneksi1.php");
include("kode_auto.php");
$option = $_REQUEST["option"];
$find = $_REQUEST["find"];
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Yamaha Kebon Agung Motor</title>
<meta name="keywords" content="blue, marble, design, theme, web, free templates, website templates, CSS, HTML" />
<meta name="description" content="Blue Marble Theme is a free website template provided by templatemo.com" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />


<style type="text/css">
<!--
#apDiv1 {
	position:absolute;
	left:176px;
	top:227px;
	width:52px;
	height:56px;
	z-index:1;
}
-->
</style>


</head>
<body>

<?php
$PO=$_REQUEST['NO_RETUR'];?>

<!-- end of header wrapper -->
<div id="templatemo_main_wrapper">
	<div id="templatemo_main">   
    	<div id="templatemo_content">
<div class="last_content_box">
                <h2><strong>Detail Retur</strong> <strong>Suku cadang</strong></h2>
                <p>&nbsp;</p>
        <div class="service_box">
          <div class="cleaner">
            <!-- ui-dialog -->
            <div id="dialog" title="Jenis Customer"></div>
            <form id="forms2" action="<?php if($PO!="0" || $PO==null ){ ?>" "display_retur.php" <?php } else { ?>"print_retur_proses.php" <?php } ?>  method="post" onsubmit="return submitForm('<?=$_SERVER['PHP_SELF'];?>')" >
              <table width="100%">
                <tr>
                  <td width="24%">No. Retur</td>
                  <td width="2%">:</td>
                  <td width="74%"><?php echo $PO; ?></td>
                </tr>
                <?php
		if ($msg!='') {
			echo "
			<tr>
				<td> </td>
				<td> </td>
				<td> $msg </td>
			</tr>";
		}
	?>
              </table>
            </form>
            <form id="forms" action="print_retur_proses.php" method="post" onsubmit="return submitForm('<?=$_SERVER['PHP_SELF'];?>')" target="_blank">
              <table width="100%">
                <?php
		if ($msg!='') {
			echo "
			<tr>
				<td> </td>
				<td> </td>
				<td> $msg </td>
			</tr>";
		}
	?>
                <tr>
                  <td width="100%"><?php if($_REQUEST['NO_RETUR']!=null){ ?>
                      <input name="NO" type="hidden" value="<?php echo $PO; ?> " />
                      <table width="603" border="1" align="center"  cellpadding="0" cellspacing="0">
                        <tr>
                          <td width="25" bgcolor="#330033"><div align="center" class="style23"><strong>No</strong></div></td>
                          <td width="83" bgcolor="#330033"><div align="center" class="style23"><strong>ID Barang</strong></div></td>
                          <td width="148" bgcolor="#330033"><div align="center" class="style23"><strong>Nama Barang</strong></div></td>
                          <td width="121" bgcolor="#330033"><div align="center" class="style23"><strong>Jml Retur</strong></div></td>
                        </tr>
                        <?php 
$sql2= "select dp.*, b.NAMA_BARANG FROM detail_retur dp, barang b where dp.ID_BARANG=b.ID_BARANG AND dp.NO_RETUR='$PO' ";
$hasil = mysql_query($sql2);
$i=0;
while($row=mysql_fetch_array($hasil)){
$i++;
?>
                        <tr>
                          <td height="30" class="style18"><div align="center" class="style24 style24"><?php echo $i; ?></div></td>
                          <td class="style18"><div align="center" class="style24 style24"><?php echo $row['ID_BARANG']; ?></div></td>
                          <td class="style18"><div align="center" class="style24 style24"><?php echo $row['NAMA_BARANG']; ?></div></td>
                          <td class="style18"><div align="center" class="style24 style24"><?php echo $row['JUMLAH_RETUR']; ?> </div></td>
                        </tr>
                        <?php 
}
?>
                      </table>
                    <p>
                        <?php
   } ?>
                      </p>
                    <p>&nbsp;</p></td>
                </tr>
                <tr>
                  <td><input type='submit' name='print' value='Cetak'/></td>
                </tr>
              </table>
            </form>
          </div>
          <div class="cleaner"></div>
        </div>
</div>
    	</div> <!-- end of content -->
   	  <div class="cleaner"></div>
    </div> <!-- end of main -->
</div> <!-- end of main wrapper -->
<!-- end of templatemo_footer wrapper -->

</body>
</html>




<?php 
} 	  				
	else 
   		{
      		echo "<script>alert(' ANDA TIDAK MEMILIKI HAK AKSES');</script>";
	  		echo "<meta http-equiv=\"refresh\" content=\"1;url=home.php\">";
		}
?>