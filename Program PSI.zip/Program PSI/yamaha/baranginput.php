<?php
session_start(); 
$tes=$_SESSION['level'];
	
	if(!isset($_SESSION['username'])OR($_SESSION['password']))
		{
		echo "<meta http-equiv=\"refresh\" content=\"1;url=home.php\">";
		}		
	if ($_SESSION['level'] == "OTO-001")
   		{   
		echo "<p>Selamat Datang ".$_SESSION['username']."</p>";

include ("koneksi1.php");
include("kode_auto.php");
$option = $_REQUEST["option"];
$find = $_REQUEST["find"];
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Yamaha Kebon Agung Motor</title>
<meta name="keywords" content="blue, marble, design, theme, web, free templates, website templates, CSS, HTML" />
<meta name="description" content="Blue Marble Theme is a free website template provided by templatemo.com" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />


<script type="text/javascript"> 
	function validasi(){
		var text=document.forms["form1"]["ID_TIPE"].value
		if(text=="-- Tipe Barang --"){
			alert("Tipe barang harus di isi !!!");
			return false;
		}
		
		var text=document.forms["form1"]["NAMA_BARANG"].value
		if(text==null || text=="" || text==0){
			alert("Nama barang harus di isi !!!");
			return false;
		}	
		
		var text=document.forms["form1"]["STOK_BARANG"].value
		if(text==null || text=="" || text==0){
			alert("Stok barang harus di isi !!!");
			return false;
		}	
		
		var text=document.forms["form1"]["STOK_BARANG"].value
		pola_username=/^[0-9]{1,100}$/;
   		if (!pola_username.test(text)){
      		alert("Stok barang harus di isi dengan angka !!!");
      		return false;
   		}
	}
</script>

<script>
function confirmDelete(delUrl) {
  if (confirm("Apakah anda yakin untuk menghapus data ini ??")) {
    document.location = delUrl;
  }
}
</script>


<style type="text/css">
<!--
.style2 {	color: #FFFFFF;
	font-weight: bold;
}
.style3 {font-size: 16px}
.style12 {color: #000000}
.style23 {font-size: 14; font-weight: bold; }
.style24 {
	font-size: 14px;
	font-weight: bold;
}
#apDiv1 {
	position:absolute;
	left:176px;
	top:227px;
	width:52px;
	height:56px;
	z-index:1;
}
.style25 {font-size: 14px}
-->
</style>


</head>
<body>
<div id="templatemo_header_wrapper">
	<div id="templatemo_header">
    
    	<div id="site_title">
            <a href="http://www.templatemo.com"><span><strong>Part _and_ Accessories</strong></span></a>        </div> 
<!-- end of site_title -->
<div id="social_box"> <a href="http://www.stumbleupon.com/" target="_blank"><img src="images/stumbleupon.png" alt="stumbleupon" /></a> <a href="http://digg.com/" target="_blank"><img src="images/digg.png" alt="digg" /></a> <a href="http://www.facebook.com/" target="_blank"><img src="images/facebook.png" alt="facebook" /></a> <a href="https://twitter.com/" target="_blank"><img src="images/twitter.png" alt="twitter" /></a> <a href="http://feeds.feedburner.com/BasicBlogTips" target="_blank"><img src="images/feed.png" alt="feed" /></a> </div>
<div id="templatemo_menu">
            <ul>
                <li><a href="home.php">Home</a></li>
            </ul>    	
      </div> <!-- end of templatemo_menu -->
    
    </div> <!-- end of header -->
</div> <!-- end of header wrapper -->

<div id="templatemo_main_wrapper">
	<div id="templatemo_main">
    
    	<div id="templatemo_content">
<div class="last_content_box">
                <h2></h2>
                

<style type="text/css">
<!--
a:link {
	text-decoration: none;
	color: ##4f7eff;
}
a:visited {
	text-decoration: none;
	color: ##4f7eff;
}
a:hover {
	text-decoration: none;
}
a:active {
	text-decoration: none;
}
.style1 {color: #FF00FF}
-->
</style>


<h3 align="center" class="style2"><a href="baranginput.php"><img src="images/table.png" width="100" height="107" /></a> <a href="baranginput.php?option=update"><img src="images/new_data.png" width="94" height="100" /></a><a href="baranginput.php?option=cari"><img src="images/search data.png" width="105" height="105" /></a></h3>
<p align="center">&nbsp;</p>


<?php		   
if($option =="")
{
$batasan=5;
$angka=$_GET['angka'];
$batas=$_GET[batas];
$halaman=$_GET['halaman'];
if(empty($halaman)){
	$posisi=0;
	$halaman=1;
}
else{
	$posisi = ($halaman-1)*$batas;
}
?>

<form action="<?php $file ?>" method="get">
<?php
echo"<input type=hidden name=halaman value=$halaman>
	 Tentukan Tampilan Data Per Halaman :";?>
	<select name=batas onchange="this.form.submit()">
<?php
//echo "<option value=$angka>";
for($j=1;$j<=6;$j++){
	$angka=$batasan*$j;?>	
    <?php
	if($batas==$angka)
		echo "<option value=$angka selected>$angka</option>";
		else
			echo "<option value=$angka>$angka</option>";}?>
</select>
</form>
</br>
<?php
if(empty($batas)){
	$batas=$batasan;}
else{
	$batas=$batas;
	
}		   
?>


<table width="604" border="1" align="center"  cellpadding="0" cellspacing="0">
<tr>
	<td width="31" bgcolor="#FFFF66"> <div align="center" class="style4 style12 style3"><strong>No</strong></div> </td>
	<td width="80" bgcolor="#FFFF66"> <div align="center" class="style4 style12 style3"><strong>ID Barang</strong></div> </td>
	<td width="105" bgcolor="#FFFF66"> <div align="center" class="style4 style12 style3"><strong> Tipe</strong></div> </td>
	<td width="134" bgcolor="#FFFF66"> <div align="center" class="style4 style12 style3"><strong>Nama Barang</strong></div> </td>
	<td width="78" bgcolor="#FFFF66"> <div align="center" class="style4 style12 style3"><strong>Stok Barang</strong></div> </td>
	<td width="54" bgcolor="#FFFF66"> <div align="center" class="style4 style12 style3"><strong>Stok Kritis</strong></div> </td>
	<td width="106" bgcolor="#FFFF66"> <div align="center" class="style4 style12 style3"><strong>Kontrol</strong></div> </td>	
</tr>
<?php 
if(isset($find))
	{
	$sql2= "select *,NAMA_TIPE  from barang,tipe_barang where NAMA_BARANG like '%$find%' and barang.ID_TIPE = tipe_barang.ID_TIPE";
	}
else
	{
	$sql2= "select *,NAMA_TIPE from barang,tipe_barang where barang.ID_TIPE = tipe_barang.ID_TIPE ORDER BY ID_BARANG ASC LIMIT $posisi,$batas";
	}

$hasil = mysql_query($sql2);
$i=0+$posisi;

while($row=mysql_fetch_array($hasil)){
$i++;
?>

<tr>
	<td> <div align="center" class="style25 style25"><?php echo $i; ?></div></td>
	<td> <div align="center" class="style25 style25"><?php echo $row['ID_BARANG']; ?>  </div></td>
	<td> <div align="center" class="style25 style25"><?php echo $row['NAMA_TIPE']; ?></div></td>
	<td> <div align="center" class="style25 style25"><?php echo $row['NAMA_BARANG']; ?> </div></td>
	<td> <div align="center" class="style25 style25"><?php echo $row['STOK_BARANG']; ?> </div></td>
	<td> <div align="center" class="style25 style25"><?php echo $row['STOK_KRITIS']; ?></div></td>
	<td><div align="center" class="style25 style25"><a href="baranginput.php?option=update&amp;ID_BARANG=<?php echo $row['ID_BARANG'];?>"><img src="images/edit-icon.png" alt="" width="39" height="36" /></a>||<a href=	 		"barangproses.php?option=delete&ID_BARANG=<?php echo $row['ID_BARANG'];?>" >
	  </a><a href="barangproses.php?option=delete&amp;ID_BARANG=<?php echo $row['ID_BARANG'];?>" onclick="return confirm('Apakah anda yakin untuk menghapus data ini ??')"><img src="images/delete.png" alt="" width="32" height="35" /></a></div></td>	
</tr>
<?php 
}
?>
</table>


<?php 
echo "<br>Halaman : ";
$tampil2 = mysql_query("select * from barang");
$jmldata = mysql_num_rows ($tampil2);
$jmlhalaman = ceil($jmldata/$batas);
$file = "baranginput.php";
for($k=1;$k<=$jmlhalaman;$k++)
if($k != $halaman){
	echo "<a href=$file?halaman=$k&batas=$batas>$k</a> | ";
}
else{
	echo "<b>$k</b> | ";
	}
echo "<p>Total barang : <b>$jmldata</b> barang</p>";
}
?>



<?php
if($option=="cari"){
?>
<form id="form1" name="form1" action="baranginput.php" method="post"><table width="439" border="0" align="center">
  <tr>
    <td width="175"><span class="style24">Nama Barang</span></td>
    <td width="144"><label>
      <input type="text" name="find" id="find">
    </label></td>
    <td width="98"><label>
      <input type="submit" name="button" id="button" value="Search">
    </label></td>
  </tr>
</table>
</form>
<?php
}



if($option=="update"){
if(isset($_REQUEST["ID_BARANG"]))
	{
	$row=mysql_fetch_array(mysql_query("select* from barang where ID_BARANG = '".$_REQUEST["ID_BARANG"]."' "));
	$ID_BARANG=$row[0]; $ID_TIPE=$row[1]; $NAMA_BARANG =$row[2]; $STOK_BARANG=$row[3]; $STOK_KRITIS=$row[4];
	$option ="update"; $readonly = "readonly=\"true\"";
	}
else
	{
	$ID_BARANG=""; $ID_TIPE=""; $NAMA_BARANG=""; $STOK_BARANG=""; $STOK_KRITIS="";
	$option="insert"; $readonly="";
	}
	
?>
<form id="form1" name="form1" action="barangproses.php" method="post" onsubmit="return validasi()"><table width="410" border="0" align="center">
  <tr>
    <td width="199"><span class="style23">ID Barang</span></td>
    <td width="201"><label>
      <? 
	if($option=="insert"){ ?>
      <input type="text" name="ID_BARANG" id="ID_BARANG" value="<?php echo kdauto ("barang","BRG-")?>" disabled="disabled" />
      <input type='hidden' name="ID_BARANG" id="ID_BARANG"  value="<? echo kdauto("barang","BRG-"); ?>" /></label></td>
      <? } ?>
      <? 
	if($option=="update"){?> 
	  	<input type="text" name="ID_BARANG2" id="ID_BARANG2" value="<?php echo $ID_BARANG; ?>" disabled="disabled" />	
        <input type="hidden" name="ID_BARANG" id="ID_BARANG" value="<?php echo $ID_BARANG; ?>"  />
      <? } ?>
</label></td>
  </tr>
  <tr>
    <td><span class="style23">Tipe Barang</span></td>
    <td><label>
	<?php
	if($row[1]=="")
	{
	$data =mysql_query("select* from tipe_barang");
	}
	else
	{
	$data= mysql_query("select* from tipe_barang where ID_TIPE= '$row[1]' union select* from tipe_barang");
	}
	?>
    <select id="ID_TIPE" name="ID_TIPE">
    <option>-- Tipe Barang --</option>
	<?php 
	while($tipe_barang=mysql_fetch_array($data)){
	
	?>
	<option value="<?php echo $tipe_barang[0];?>"><?php echo $tipe_barang[0];?> | <?php echo $tipe_barang[1];?></option>
<?php
}
?>
	</select>
</label></td>
  </tr>
  <tr>
    <td><span class="style23">Nama Barang</span></td>
    <td><label>
      <input type="text" name="NAMA_BARANG" id="NAMA_BARANG" value="<?php echo $NAMA_BARANG; ?>">
    </label></td>
  </tr>
  <tr>
    <td><span class="style23">Stok Barang</span></td>
    <td><label>
      <input type="text" name="STOK_BARANG" id="STOK_BARANG" value="<?php echo $STOK_BARANG; ?>">
    </label></td>
  </tr>
  
  <tr>
    <td>&nbsp;</td>
    <td> <label>
      <input type="submit" name="button2" id="button2" value="Submit">
      <input type="reset" name="button3" id="button3" value="Cancel" onClick="self.history.back()">
      <input type="hidden" name="option" id="option" value="<?php echo $option;?>"></th>
    </label></td>
  </tr>
</table>
</form>


<?php 
}
?>
               
                
<div class="service_box"><div class="cleaner"></div>
          <div class="cleaner"></div>
        </div>
                
          </div>
    	</div> <!-- end of content -->
        
        <div id="templatemo_sidebar">
        	<div class="sidebar_box"><img src="images/templatemo_ads.png" width="250" height="250" /></div>  
        	
            <div class="sidebar_box">
              <ul class="tmo_list">
                <p>
                  <?php
		include "cek.php";
		session_start();
			
						
if ($_SESSION['level'] == "OTO-001")		
{
     
      echo "<p>Selamat Datang ".$_SESSION['username']."</p>";?>
                </p>
                <p>&nbsp; </p>
                <blockquote>
                  <p class="style3"><strong><a href="ubah_password.php">Ubah Password</a></strong></p>
                  <p class="style3">&nbsp;</p>
                  <p class="style3"><strong>Master</strong></p>
                </blockquote>
                <ul class="MenuBarVertical">
                  <ul>
                    <li><a href="karyawanInput.php">karyawan</a></li>
                    <li><a href="baranginput.php">barang</a></li>
                    <li><a href="tipeBarang_input.php">tipe barang</a></li>
                    <li><a href="hargaBarangInput.php">harga barang</a></li>
                    <li><a href="diskon_input.php">diskon</a></li>
                    <li><a href="otoritasinput.php">otoritas</a></li>
                  </ul>
                </ul>
                <blockquote>
                  <p class="style3">&nbsp;</p>
                </blockquote>
                <h4><a href="logout.php" class="style2"><strong>Logout</strong></a></h4>
                <p>
                  <?php		
}



else if ($_SESSION['level'] == "OTO-002")
  	 {
     
      echo "<p>Selamat Datang ".$_SESSION['username']."</p>";?>
                </p>
                <p>&nbsp; </p>
                <blockquote>
                  <p class="style3"><strong><a href="ubah_password.php">Ubah Password</a></strong></p>
                  <p class="style3">&nbsp;</p>
                  <p class="style3"><strong>Persetujuan</strong></p>
                </blockquote>
                <ul>
                  <li><a href="acc_pemesanan.php">ACC pemesanan</a></li>
                </ul>
                <blockquote>
                  <p class="style3">&nbsp;</p>
                  <p class="style3"><strong>Inventori</strong></p>
                  <ul>
                    <li><a href="inventori.php">daftar suku cadang</a></li>
                  </ul>
                  <p>&nbsp;</p>
                  <p class="style3"><strong>Laporan</strong></p>
                </blockquote>
                <ul>
                  <ul>
                    <li><a href="lap_pemesanan.php">pemesanan</a></li>
                    <li><a href="lap_penerimaan.php">penerimaan</a></li>
                    <li><a href="lap_retur.php">retur</a></li>
                    <li><a href="lap_pnr_retur.php">penerimaan retur</a></li>
                    <li><a href="lap_penjualan.php">penjualan</a>
                      <blockquote>
                        <p>&nbsp;</p>
                      </blockquote>
                    </li>
                  </ul>
                </ul>
                <h4><a href="logout.php" class="style2"><strong> Logout</strong></a></h4>
                <p>
                  <?php
		 
}



else if ($_SESSION['level'] == "OTO-003")
{
     
      echo "<p>Selamat Datang ".$_SESSION['username']."</p>";?>
                </p>
                <blockquote>
                  <blockquote>&nbsp;</blockquote>
                  <p class="style3"><strong><a href="ubah_password.php">Ubah Password</a></strong></p>
                  <p class="style3">&nbsp;</p>
                  <p class="style3"><strong>Transaksi</strong></p>
                  <ul>
                    <li><a href="history_pemesanan.php">history pemesanan</a></li>
                    <li><a href="pemesanan.php">pemesanan</a></li>
                    <li><a href="penerimaan.php">penerimaan</a></li>
                    <li><a href="display_retur.php">display retur</a></li>
                    <li><a href="rtr_penerimaan.php">penerimaan retur</a></li>
                    <li><a href="penjualan.php">penjualan</a></li>
                    <li><a href="his_penjualan.php">history penjualan</a></li>
                  </ul>
                  <p class="style3">&nbsp;</p>
                </blockquote>
                <h4><a href="logout.php" class="style2"><strong>Logout</strong></a></h4>
                <p>
                  <?php
	   
}
	
	
	
?>
                </p>
              </ul>
          </div>
      </div>
      <div class="cleaner"></div>
    </div> <!-- end of main -->
</div> <!-- end of main wrapper -->

<div id="templatemo_footer_wrapper">
	<div id="templatemo_footer">    
        <p><center><strong>Copyright © 2016</strong><strong><br />
        Yamaha Kebon Agung Motor</strong><strong><br />
		</strong></center></p>
    </div>
    
	<div class="cleaner"></div>
</div> <!-- end of templatemo_footer -->

</body>
</html>




<?php 
} 	  				
	else 
   		{
      		echo "<script>alert(' ANDA TIDAK MEMILIKI HAK AKSES');</script>";
	  		echo "<meta http-equiv=\"refresh\" content=\"1;url=home.php\">";
		}
?>