<?php
ob_start();
session_start(); 
$tes=$_SESSION['level'];
	if(!isset($_SESSION['username'])OR($_SESSION['password']))
		{
		echo "<meta http-equiv=\"refresh\" content=\"1;url=home.php\">";
		}		
	if ($_SESSION['level'] == "OTO-002")
   		{   
		echo "<p>Selamat Datang ".$_SESSION['username']."</p>";

include ("koneksi1.php");
include("kode_auto.php");
$option = $_REQUEST["option"];
$find = $_REQUEST["find"];
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Yamaha Kebon Agung Motor</title>
<meta name="keywords" content="blue, marble, design, theme, web, free templates, website templates, CSS, HTML" />
<meta name="description" content="Blue Marble Theme is a free website template provided by templatemo.com" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />


<style type="text/css">
<!--
.style2 {	color: #FFFFFF;
	font-weight: bold;
}
.style3 {font-size: 16px}
#apDiv1 {
	position:absolute;
	left:176px;
	top:227px;
	width:52px;
	height:56px;
	z-index:1;
}
-->
</style>


</head>
<body>
<div id="templatemo_header_wrapper">
	<div id="templatemo_header">   
    	<div id="site_title">
            <a href="http://www.templatemo.com"><span><strong>           
            Part _and_ Accessories</strong></span></a>        
            </div> 
<!-- end of site_title -->
<div id="social_box"> <a href="http://www.stumbleupon.com/" target="_blank"><img src="images/stumbleupon.png" alt="stumbleupon" /></a> <a href="http://digg.com/" target="_blank"><img src="images/digg.png" alt="digg" /></a> <a href="http://www.facebook.com/" target="_blank"><img src="images/facebook.png" alt="facebook" /></a> <a href="https://twitter.com/" target="_blank"><img src="images/twitter.png" alt="twitter" /></a> <a href="http://feeds.feedburner.com/BasicBlogTips" target="_blank"><img src="images/feed.png" alt="feed" /></a> </div>
<div id="templatemo_menu">
            <ul>
                <li><a href="home.php">Home</a></li>
            </ul>    	
      </div> <!-- end of templatemo_menu -->    
    </div> <!-- end of header -->
</div> <!-- end of header wrapper -->


<?php
$PO=$_REQUEST['NO_PEMESANAN'];?>


<div id="templatemo_main_wrapper">
	<div id="templatemo_main">   
    	<div id="templatemo_content">
<div class="last_content_box">
                <h2><strong>ACC Pemesanan</strong> <strong>Suku cadang</strong></h2>
                <p>&nbsp;</p>
        <p>&nbsp;</p>
        <div class="service_box"><div class="cleaner">
        
        
<form id="forms2" action=<?php if($PO!="0" || $PO==null ){ ?> "acc_pemesanan.php" <?php } else { ?>"acc_pemesanan_proses.php" <?php } ?>  method="POST" onSubmit="return submitForm('<?=$_SERVER['PHP_SELF'];?>')">
<table width="100%">
  <tr>
    <td> Tanggal </td>
    <td> : </td>
    <td><? echo date('Y-m-d');?> </td>
  </tr>
	<?php
		if ($msg!='') {
			echo "
			<tr>
				<td> </td>
				<td> </td>
				<td> $msg </td>
			</tr>";
		}
	?>
	
	<tr>
	  <td width="24%">No. Pemesanan</td>
	  <td width="2%">:</td>
	  <td width="74%"><label>
	    <select name="NO_PEMESANAN" id="NO_PEMESANAN" onchange="this.form.submit()">
          <option>-- No. Pemesanan --</option>
          <?php
				//mengambil No. Pemesanan yang ada di database
				$NO_PEMESANAN = mysql_query("SELECT * FROM pemesanan_barang where STATUS_ACC='0'");
				while($tb=mysql_fetch_array($NO_PEMESANAN)){
				?>
          <option value = "<?php echo $tb[NO_PEMESANAN]?>"> <?php echo $tb[NO_PEMESANAN]?> </option>
          <?
				}
				?>
        </select>
	  </label></td>
	  </tr>
</table>
<p>&nbsp;</p>
<p>&nbsp;</p>
</form>        
       
<form id="forms" action="acc_pemesanan_proses.php" method="POST" onSubmit="return submitForm('<?=$_SERVER['PHP_SELF'];?>')">
<table width="100%">
	<?php
		if ($msg!='') {
			echo "
			<tr>
				<td> </td>
				<td> </td>
				<td> $msg </td>
			</tr>";
		}
	?>
	<tr>
		<td width="100%">
        <input name="NO_PES" type="hidden" value="<?php echo $PO; ?>" />
<?php if($_REQUEST['NO_PEMESANAN']!=null){ ?>     
<table width="600" border="1" align="center"  cellpadding="0" cellspacing="0">
<tr>
	<td width="30" bgcolor="#330033"> <div align="center" class="style23"><strong>No</strong></div> </td>
	<td width="147" bgcolor="#330033"> <div align="center" class="style23"><strong>Barang</strong></div> </td>
    <td width="147" bgcolor="#330033"> <div align="center" class="style23"><strong>Nama Barang</strong></div> </td>
	<td width="99" bgcolor="#330033"> <div align="center" class="style23"><strong>Jumlah</strong></div> </td>
	<td width="142" bgcolor="#330033"> <div align="center" class="style23"><strong>Harga Satuan</strong></div> </td>	
</tr>
<?php 
$sql2= "select dp.*, b.NAMA_BARANG FROM detail_pemesanan dp, barang b where dp.ID_BARANG=b.ID_BARANG AND dp.NO_PEMESANAN='$PO' ";
$hasil = mysql_query($sql2);
$i=0;
while($row=mysql_fetch_array($hasil)){
$i++;
?>

<tr>
	<td height="30" class="style18"> <div align="center" class="style24 style24"><?php echo $i; ?></div></td>
	<td class="style18"> <div align="center" class="style24 style24"><?php echo $row['ID_BARANG']; ?></div></td>
    <td class="style18"> <div align="center" class="style24 style24"><?php echo $row['NAMA_BARANG']; ?></div></td>
	<td class="style18"> <div align="center" class="style24 style24"><?php echo $row['JUMLAH_PEMESANAN']; ?> </div></td>
	<td class="style18"><div align="center" class="style24 style24"><?php echo $row['HARGA_BELI']; ?> </div></td>	
</tr>
<?php 
}
?>
</table>
<p>&nbsp;</p>
<table width="600" border="0">
  <tr>
    <td width="81"><strong>Keterangan</strong></td>
    <td width="18"><div align="center"><strong>:</strong></div></td>
    <td width="479">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="3"><span class="style24 style24">
      <textarea name="KETERANGAN" id="KETERANGAN" cols="45" rows="5"></textarea>
    </span></td>
    </tr>
</table>
<p>
  <?php
   } ?>
</p>
</td>
		</tr>
	<tr>
	  <td><input type='submit' name='setuju' value='Setuju' id="setuju"/> <label>
	    <input type="submit" name="tolak" id="button" value="Tolak" />
	  </label></td>
	  </tr>
</table>
</form></div>
          <div class="cleaner"></div>
        </div>
                
          </div>
    	</div> <!-- end of content -->
        
        <div id="templatemo_sidebar">
        	<div class="sidebar_box"><img src="images/templatemo_ads.png" width="250" height="250" /></div>  
        	
            <div class="sidebar_box">
              <ul class="tmo_list">
                <p>
                  <?php
		include "cek.php";
		session_start();
			
						
if ($_SESSION['level'] == "OTO-001")		
{
     
      echo "<p>Selamat Datang ".$_SESSION['username']."</p>";?>
                </p>
                <p>&nbsp; </p>
                <blockquote>
                  <p class="style3"><strong><a href="ubah_password.php">Ubah Password</a></strong></p>
                  <p class="style3">&nbsp;</p>
                  <p class="style3"><strong>Master</strong></p>
                </blockquote>
                <ul class="MenuBarVertical">
                  <ul>
                    <li><a href="karyawanInput.php">karyawan</a></li>
                    <li><a href="baranginput.php">barang</a></li>
                    <li><a href="tipeBarang_input.php">tipe barang</a></li>
                    <li><a href="hargaBarangInput.php">harga barang</a></li>
                    <li><a href="diskon_input.php">diskon</a></li>
                    <li><a href="otoritasinput.php">otoritas</a></li>
                  </ul>
                </ul>
                <blockquote>
                  <p class="style3">&nbsp;</p>
                </blockquote>
                <h4><a href="logout.php" class="style2"><strong>Logout</strong></a></h4>
                <p>
                  <?php		
}



else if ($_SESSION['level'] == "OTO-002")
  	 {
     
      echo "<p>Selamat Datang ".$_SESSION['username']."</p>";?>
                </p>
                <p>&nbsp; </p>
                <blockquote>
                  <p class="style3"><strong><a href="ubah_password.php">Ubah Password</a></strong></p>
                  <p class="style3">&nbsp;</p>
                  <p class="style3"><strong>Persetujuan</strong></p>
                </blockquote>
                <ul>
                  <li><a href="acc_pemesanan.php">ACC pemesanan</a></li>
                </ul>
                <blockquote>
                  <p class="style3">&nbsp;</p>
                  <p class="style3"><strong>Inventori</strong></p>
                  <ul>
                    <li><a href="inventori.php">daftar suku cadang</a></li>
                  </ul>
                  <p>&nbsp;</p>
                  <p class="style3"><strong>Laporan</strong></p>
                </blockquote>
               <ul><ul><li><a href="lap_pemesanan.php">pemesanan</a></li>
                  <li><a href="lap_penerimaan.php">penerimaan</a></li>
                  <li><a href="lap_retur.php">retur</a></li>
                  <li><a href="lap_pnr_retur.php">penerimaan retur</a></li>
                  <li><a href="lap_penjualan.php">penjualan</a></li>
                  <li><a href="lap_master_karyawan.php">Laporan Master Karyawan</a></li>
                  <li><a href="lap_master_hargaBarang.php">Laporan Master Harga Barang</a></li>
                  <li><a href="lap_master_Barang.php">Laporan Master Barang</a></li>
                  <li><a href="lap_master_tipeBarang.php">Laporan Master Tipe Barang</a></li>
                      <blockquote>
                        <p>&nbsp;</p>
                      </blockquote>
                    </li>
                  </ul>
                </ul>
                <h4><a href="logout.php" class="style2"><strong> Logout</strong></a></h4>
                <p>
                  <?php
		 
}



else if ($_SESSION['level'] == "OTO-003")
{
     
      echo "<p>Selamat Datang ".$_SESSION['username']."</p>";?>
                </p>
                <blockquote>
                  <blockquote>&nbsp;</blockquote>
                  <p class="style3"><strong><a href="ubah_password.php">Ubah Password</a></strong></p>
                  <p class="style3">&nbsp;</p>
                  <p class="style3"><strong>Transaksi</strong></p>
                  <ul>
                    <li><a href="history_pemesanan.php">history pemesanan</a></li>
                    <li><a href="pemesanan.php">pemesanan</a></li>
                    <li><a href="penerimaan.php">penerimaan</a></li>
                    <li><a href="display_retur.php">display retur</a></li>
                    <li><a href="rtr_penerimaan.php">penerimaan retur</a></li>
                    <li><a href="penjualan.php">penjualan</a></li>
                    <li><a href="his_penjualan.php">history penjualan</a></li>
                  </ul>
                  <p class="style3">&nbsp;</p>
                </blockquote>
                <h4><a href="logout.php" class="style2"><strong>Logout</strong></a></h4>
                <p>
                  <?php
	   
}
	
	
	
?>
                </p>
              </ul>
          </div>
      </div>
      <div class="cleaner"></div>
    </div> <!-- end of main -->
</div> <!-- end of main wrapper -->

<div id="templatemo_footer_wrapper">
	<div id="templatemo_footer">    
        <p><center><strong>Copyright © 2016</strong><strong><br />
        Yamaha Kebon Agung Motor</strong><strong><br />
		</strong></center></p>
    </div>
    
	<div class="cleaner"></div>
</div> <!-- end of templatemo_footer -->

</body>
</html>




<?php 
} 	  				
	else 
   		{
      		echo "<script>alert(' ANDA TIDAK MEMILIKI HAK AKSES');</script>";
	  		echo "<meta http-equiv=\"refresh\" content=\"1;url=home.php\">";
		}
?>