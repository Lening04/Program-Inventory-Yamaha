<?php
session_start(); 
$tes=$_SESSION['level'];
	
	if(!isset($_SESSION['username'])OR($_SESSION['password']))
		{
		echo "<meta http-equiv=\"refresh\" content=\"1;url=home.php\">";
		}		
	if ($_SESSION['level'] == "OTO-001")
   		{   
		echo "<p>Selamat Datang ".$_SESSION['username']."</p>";

include ("koneksi1.php");
include("kode_auto.php");
$option = $_REQUEST["option"];
$find = $_REQUEST["find"];
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Yamaha Kebon Agung Motor</title>
<meta name="keywords" content="blue, marble, design, theme, web, free templates, website templates, CSS, HTML" />
<meta name="description" content="Blue Marble Theme is a free website template provided by templatemo.com" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />

<script type="text/javascript" src="js/jquery-1.4.2.js"></script>
<link type="text/css" href="js/development-bundle/themes/base/ui.all.css" rel="stylesheet" />
<script type="text/javascript" src="js/development-bundle/ui/ui.core.js"></script>
<script type="text/javascript" src="js/development-bundle/ui/ui.datepicker.js"></script>

<script type="text/javascript">  
      $(function() {  
         $('#TANGGAL').datepicker({  
                  dateFormat:'yy-mm-dd',
                  changeYear: true,
				  changeMonth: true 
				 
              });  
      });  
	  
	  function validasi(){
		var text=document.forms["form1"]["TANGGAL"].value
		if(text==null || text=="" || text==0){
			alert("Tanggal harus di isi !!!");
			return false;
		}	
		
		var text=document.forms["form1"]["ID_BARANG"].value
		if(text=="-- Barang --" ){
			alert("Barang harus di isi !!!");
			return false;
		}
		
		var text=document.forms["form1"]["HARGA_JUAL"].value
		if(text==null || text=="" || text==0){
			alert("Harga Jual harus di isi !!!");
			return false;
		}	
		
		var text=document.forms["form1"]["HARGA_JUAL"].value
		pola_username=/^[0-9]{1,100}$/;
   		if (!pola_username.test(text)){
      		alert("Harga jual harus di isi dengan angka !!!");
      		return false;
   		}
		
		var text=document.forms["form1"]["HARGA_BELI"].value
		if(text==null || text=="" || text==0){
			alert("Harga beli harus di isi !!!");
			return false;
		}	
		
		var text=document.forms["form1"]["HARGA_BELI"].value
		pola_username=/^[0-9]{1,100}$/;
   		if (!pola_username.test(text)){
      		alert("Harga jual harus di isi dengan angka !!!");
      		return false;
   		}
		
		var text=document.forms["form1"]["STATUS"].value
		if(text=="-- Status --" ){
			alert("Status harus di isi !!!");
			return false;
		}	
	}
  </script> 
  
<script>
function confirmDelete(delUrl) {
  if (confirm("Apakah anda yakin untuk menghapus data ini ??")) {
    document.location = delUrl;
  }
}
</script>


<style type="text/css">
<!--
.style2 {	color: #FFFFFF;
	font-weight: bold;
}
.style3 {font-size: 16px}
.style12 {color: #000000}
.style14 {font-size: 12px}
.style15 {font-size: 13px}
.style18 {font-size: 14; font-weight: bold; }
.style19 {
	font-size: 14px;
	font-weight: bold;
}
.style20 {font-size: 14px}
-->
</style>
</head>
<body>

<div id="templatemo_header_wrapper">
	<div id="templatemo_header">
    
    	<div id="site_title">
            <a href="http://www.templatemo.com"><span><strong>Part _and_ Accessories</strong></span></a>        </div> 
<!-- end of site_title -->
<div id="social_box"> <a href="http://www.stumbleupon.com/" target="_blank"><img src="images/stumbleupon.png" alt="stumbleupon" /></a> <a href="http://digg.com/" target="_blank"><img src="images/digg.png" alt="digg" /></a> <a href="http://www.facebook.com/" target="_blank"><img src="images/facebook.png" alt="facebook" /></a> <a href="https://twitter.com/" target="_blank"><img src="images/twitter.png" alt="twitter" /></a> <a href="http://feeds.feedburner.com/BasicBlogTips" target="_blank"><img src="images/feed.png" alt="feed" /></a> </div>
<div id="templatemo_menu">
            <ul>
                <li><a href="home.php">Home</a></li>
            </ul>    	
      </div> <!-- end of templatemo_menu -->
    
    </div> <!-- end of header -->
</div> <!-- end of header wrapper -->

<div id="templatemo_main_wrapper">
	<div id="templatemo_main">
    
    	<div id="templatemo_content">
<div class="last_content_box">
                <h2></h2>
                
                
                
                
<style type="text/css">
<!--
a:link {
	text-decoration: none;
	color: ##4f7eff;
}
a:visited {
	text-decoration: none;
	color: ##4f7eff;
}
a:hover {
	text-decoration: none;
}
a:active {
	text-decoration: none;
}
.style1 {font-weight: bold}
.style2 {color: #FF00FF}
-->
</style>
<h3 align="center" class="style2"><a href="hargaBarangInput.php"><img src="images/table.png" width="100" height="107" /></a> <a href="hargaBarangInput.php?option=update"><img src="images/new_data.png" width="94" height="100" /></a><a href="hargaBarangInput.php?option=cari"><img src="images/search data.png" width="105" height="105" /></a></h3>
<p align="center">&nbsp;</p>


<?php		   
if($option =="")
{
$batasan=5;
$angka=$_GET['angka'];
$batas=$_GET[batas];
$halaman=$_GET['halaman'];
if(empty($halaman)){
	$posisi=0;
	$halaman=1;
}
else{
	$posisi = ($halaman-1)*$batas;
}
?>

<form action="<?php $file ?>" method="get">
<?php
echo"<input type=hidden name=halaman value=$halaman>
	 Tentukan Tampilan Data Per Halaman :";?>
	<select name=batas onchange="this.form.submit()">
<?php
//echo "<option value=$angka>";
for($j=1;$j<=6;$j++){
	$angka=$batasan*$j;?>	
    <?php
	if($batas==$angka)
		echo "<option value=$angka selected>$angka</option>";
		else
			echo "<option value=$angka>$angka</option>";}?>
</select>
</form>
</br>
<?php
if(empty($batas)){
	$batas=$batasan;}
else{
	$batas=$batas;
	
}		   
?>


<table width="605" border="1" align="center"  cellpadding="0" cellspacing="0">
<tr>
	<td width="23" bgcolor="#FFFF66" class="style14"> <div align="center" class="style12 style4 style3"><strong>No</strong></div> </td>
	<td width="53" bgcolor="#FFFF66" class="style14"> <div align="center" class="style12 style4 style3"><strong>ID Harga</strong></div> </td>
	<td width="89" bgcolor="#FFFF66" class="style14"><div align="center" class="style12 style4 style3"><strong>Nama Barang</strong></div></td>
	<td width="75" bgcolor="#FFFF66" class="style14"> <div align="center" class="style12 style4 style3"><strong>Tanggal</strong></div> </td>
	<td width="61" bgcolor="#FFFF66" class="style14"> <div align="center" class="style12 style4 style3"><strong>Harga Jual</strong></div> </td>
	<td width="61" bgcolor="#FFFF66" class="style14"><div align="center" class="style12 style4 style3"><strong>Harga Beli</strong></div></td>
	<td width="61" bgcolor="#FFFF66" class="style14"><div align="center" class="style12 style4 style3"><strong>Status</strong></div></td>
	<td width="96" bgcolor="#FFFF66" class="style14"> <div align="center" class="style12 style4 style3"><strong>Kontrol</strong></div> </td>	
</tr>
<?php 
if(isset($find))
	{
	$sql2= "select *,NAMA_BARANG from harga_barang,barang where NAMA_BARANG like '%$find%' and harga_barang.ID_BARANG = barang.ID_BARANG";
	}
else
	{
	$sql2= "select *,NAMA_BARANG from harga_barang,barang where harga_barang.ID_BARANG = barang.ID_BARANG ORDER BY ID_HARGA ASC LIMIT $posisi,$batas";
	}

$hasil = mysql_query($sql2);
$i=0+$posisi;

while($row=mysql_fetch_array($hasil)){
$i++;
?>

<tr>
	<td class="style15"> <div align="center" class="style20 style20"><?php echo $i; ?></div></td>
	<td class="style15"> <div align="center" class="style20 style20">
	  <?php  echo $row['ID_HARGA']; ?>  
	  </div></td>
	<td class="style15"><div align="center" class="style20 style20"><?php echo $row['NAMA_BARANG']; ?></div></td>
	<td class="style15"> <div align="center" class="style20 style20"><?php echo $row['TANGGAL']; ?> </div></td>
	<td class="style15"> <div align="center" class="style20 style20"><?php echo $row['HARGA_JUAL']; ?> </div></td>
	<td class="style15"><div align="center" class="style20 style20"><?php echo $row['HARGA_BELI']; ?></div></td>
	<td class="style15"><div align="center" class="style20 style20"><?php if($row['STATUS']==0)
	{echo 'aktif';} else if($row['STATUS']==1) {echo 'non aktif';} ?></div></td>
	<td class="style15"><div align="center" class="style20 style20"><a href="hargaBarangInput.php?option=update&amp;ID_HARGA=<?php echo $row['ID_HARGA'];?>"><img src="images/edit-icon.png" alt="" width="39" height="36" /></a>|| <a href="hargaBarangProses.php?option=delete&ID_HARGA=<?php echo $row['ID_HARGA'];?>" >
	  </a><a href="hargaBarangProses.php?option=delete&amp;ID_HARGA=<?php echo $row['ID_HARGA'];?>" onclick="return confirm('Apakah anda yakin untuk menghapus data ini ??')"><img src="images/delete.png" alt="" width="32" height="35" /></a></div></td>	
</tr>
<?php 
}
?>
</table>


<?php 
echo "<br>Halaman : ";
$tampil2 = mysql_query("select * from harga_barang");
$jmldata = mysql_num_rows ($tampil2);
$jmlhalaman = ceil($jmldata/$batas);
$file = "hargaBarangInput.php";
for($k=1;$k<=$jmlhalaman;$k++)
if($k != $halaman){
	echo "<a href=$file?halaman=$k&batas=$batas>$k</a> | ";
}
else{
	echo "<b>$k</b> | ";
	}
echo "<p>Total jenis harga : <b>$jmldata</b> jenis harga</p>";
}
?>


<?php 
if($option=="cari") {
?>
<form id="form1" name="form1" action="hargaBarangInput.php" method="post"><table width="416" border="0" align="center">
  <tr>
    <td width="143"><span class="style19">Nama Barang</span></td>
    <td width="156"><label>
      <input type="text" name="find" id="find">
    </label></td>
    <td width="95"><label>
      <input type="submit" name="button" id="button" value="Search">
    </label></td>
  </tr>
</table>
</form>
<?php
}



if($option=="update") {

if(isset($_REQUEST["ID_HARGA"]))
	{
	$row=mysql_fetch_array(mysql_query("select* from harga_barang where ID_HARGA = '".$_REQUEST["ID_HARGA"]."' "));
	$ID_HARGA=$row[0]; $ID_BARANG=$row[1]; $TANGGAL =$row[2]; $HARGA_JUAL=$row[3]; $HARGA_BELI=$row[4];
	$option ="update"; $readonly = "readonly=\"true\"";
	}
else
	{
	$ID_HARGA=""; $ID_BARANG=""; $TANGGAL=""; $HARGA_JUAL=""; $HARGA_BELI="";
	$option="insert"; $readonly="";
	}
?>


<form id="form1" name="form1" action="hargaBarangProses.php"  method="post"  enctype="multipart/form-data" onsubmit="return validasi()" ><table width="432" border="0" align="center">
  <tr>
    <td width="189"><span class="style18">ID Harga</span></td>
    <td width="195"><label>
    	 <? 
	if($option=="insert"){ ?>
      <input type="text" name="ID_HARGA" id="ID_HARGA" value="<?php echo kdauto ("harga_barang","HRG-")?>" disabled="disabled" />
      <input type='hidden' name="ID_HARGA" id="ID_HARGA"  value="<? echo kdauto("harga_barang","HRG-"); ?>" /></label></td>
      <? } ?>
      <? 
	if($option=="update"){?> 
	  	<input type="text" name="ID_HARGA2" id="ID_HARGA2" value="<?php echo $ID_HARGA; ?>" disabled="disabled" />	
        <input type="hidden" name="ID_HARGA" id="ID_HARGA" value="<?php echo $ID_HARGA; ?>"  />
      <? } ?>
      </tr>
  <tr>
    <td><span class="style18">Barang</span></td>
    <td><label>
   
    <select id="ID_BARANG" name="ID_BARANG">
    <?php
	if($row[1]=="")
	{
	$data =mysql_query("select* from barang, tipe_barang where barang.ID_TIPE=tipe_barang.ID_TIPE ORDER BY NAMA_TIPE ASC");
	?>
    <option>-- Barang --</option>
    <?php
	}
	else
	{
	$data= mysql_query("select* from barang where ID_BARANG= '$row[1]' union select* from barang");
	}
	?>  
	<?php 
	while($barang=mysql_fetch_array($data)){
	?>
	<option value="<?php echo $barang[0];?>"><?php echo $barang['NAMA_TIPE'];?> | <?php echo $barang[2];?></option>
	<?php
	}
	?>
      </select>
    </label></td>
  </tr>
  <tr>
    <td><span class="style18">Tanggal</span></td>
    <td><label>
      <input name="TANGGAL" type="text" id="TANGGAL" value="<?php echo $TANGGAL;?>" size="10" maxlength="10" />
    (yyyy-mm-dd)</label></td>
  </tr>
  <tr>
    <td><span class="style18">Harga Jual</span></td>
    <td><label>
      <input type="text" name="HARGA_JUAL" id="HARGA_JUAL" value="<?php echo $HARGA_JUAL; ?>">
    </label></td>
  </tr>
  <tr>
    <td><span class="style18">Harga Beli</span></td>
    <td><input type="text" name="HARGA_BELI" id="HARGA_BELI" value="<?php echo $HARGA_BELI; ?>" /></td>
  </tr>
  <tr>
    <td><span class="style18">Status</span></td>
    <td>
      <p>
      <label></label>
      <label>
    <?php
    $id=$row[0]; 
    $data= mysql_fetch_array(mysql_query("select * from harga_barang where ID_HARGA='$id' "));
	$st=$data['STATUS'];
	?>
    <select name="STATUS" id="STATUS">
    <?php
	if($row[5]=="")
	{
	?>
    <option>-- Status --</option>
    <option value="0">Aktif</option>
    <option value="1">Non aktif</option>
    <?php
	}
	else
	{
	if($st=="aktif"){
	?>
    <option value="0">Aktif</option>
    <option value="1">Non aktif</option>
    <?php
	}else
	{?>
	 <option value="1">Non aktif</option>
	 <option value="0">Aktif</option>
    <?php
    }}
	?>
     </select>
      </label>
      <br />
    </p>      
      <label></label>      </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><label>
      <input type="submit" name="button2" id="button2" value="Submit"> 
      <input type="reset" name="button3" id="button3" value="Cancel" onClick="self.history.back()">
      <input type="hidden" name="option" id="option" value="<?php echo $option;?>"></th>
    </label></td>
  </tr>
</table>
</form>

<?php

}

?>
                
                
                
                
                

<div class="service_box"><div class="cleaner"></div>
          <div class="cleaner"></div>
        </div>
                
          </div>
    	</div> <!-- end of content -->
        
        <div id="templatemo_sidebar">
        	<div class="sidebar_box"><img src="images/templatemo_ads.png" width="250" height="250" /></div>  
        	
            <div class="sidebar_box">
              <ul class="tmo_list">
                <p>
                  <?php
		include "cek.php";
		session_start();
			
						
if ($_SESSION['level'] == "OTO-001")		
{
     
      echo "<p>Selamat Datang ".$_SESSION['username']."</p>";?>
                </p>
                <p>&nbsp; </p>
                <blockquote>
                  <p class="style3"><strong><a href="ubah_password.php">Ubah Password</a></strong></p>
                  <p class="style3">&nbsp;</p>
                  <p class="style3"><strong>Master</strong></p>
                </blockquote>
                <ul class="MenuBarVertical">
                  <ul>
                    <li><a href="karyawanInput.php">karyawan</a></li>
                    <li><a href="baranginput.php">barang</a></li>
                    <li><a href="tipeBarang_input.php">tipe barang</a></li>
                    <li><a href="hargaBarangInput.php">harga barang</a></li>
                    <li><a href="diskon_input.php">diskon</a></li>
                    <li><a href="otoritasinput.php">otoritas</a></li>
                  </ul>
                </ul>
                <blockquote>
                  <p class="style3">&nbsp;</p>
                </blockquote>
                <h4><a href="logout.php" class="style2"><strong>Logout</strong></a></h4>
                <p>
                  <?php		
}



else if ($_SESSION['level'] == "OTO-002")
  	 {
     
      echo "<p>Selamat Datang ".$_SESSION['username']."</p>";?>
                </p>
                <p>&nbsp; </p>
                <blockquote>
                  <p class="style3"><strong><a href="ubah_password.php">Ubah Password</a></strong></p>
                  <p class="style3">&nbsp;</p>
                  <p class="style3"><strong>Persetujuan</strong></p>
                </blockquote>
                <ul>
                  <li><a href="acc_pemesanan.php">ACC pemesanan</a></li>
                </ul>
                <blockquote>
                  <p class="style3">&nbsp;</p>
                  <p class="style3"><strong>Inventori</strong></p>
                  <ul>
                    <li><a href="inventori.php">daftar suku cadang</a></li>
                  </ul>
                  <p class="style3">&nbsp;</p>
                  <p class="style3"><strong>Laporan</strong></p>
                </blockquote>
                <ul><ul><li><a href="lap_pemesanan.php">pemesanan</a></li>
                  <li><a href="lap_penerimaan.php">penerimaan</a></li>
                  <li><a href="lap_retur.php">retur</a></li>
                  <li><a href="lap_pnr_retur.php">penerimaan retur</a></li>
                  <li><a href="lap_penjualan.php">penjualan</a>
                    <blockquote>
                      <p>&nbsp;</p>
                    </blockquote>
                  </li>
                  </ul>
                </ul>
                <h4><a href="logout.php" class="style2"><strong> Logout</strong></a></h4>
                <p>
                  <?php
		 
}



else if ($_SESSION['level'] == "OTO-003")
{
     
      echo "<p>Selamat Datang ".$_SESSION['username']."</p>";?>
                </p>
                <blockquote>
                  <blockquote>&nbsp;</blockquote>
                  <p class="style3"><strong><a href="ubah_password.php">Ubah Password</a></strong></p>
                  <p class="style3">&nbsp;</p>
                  <p class="style3"><strong>Transaksi</strong></p>
                  <ul>
                    <li><a href="history_pemesanan.php">history pemesanan</a></li>
                    <li><a href="pemesanan.php">pemesanan</a></li>
                    <li><a href="penerimaan.php">penerimaan</a></li>
                    <li><a href="display_retur.php">display retur</a></li>
                    <li><a href="rtr_penerimaan.php">penerimaan retur</a></li>
                    <li><a href="penjualan.php">penjualan</a></li>
                    <li><a href="his_penjualan.php">history penjualan</a></li>
                  </ul>
                  <p class="style3">&nbsp;</p>
                </blockquote>
                <h4><a href="logout.php" class="style2"><strong>Logout</strong></a></h4>
                <p>
                  <?php
	   
}
	
	
	
?>
                </p>
              </ul>
          </div>
      </div>
      <div class="cleaner"></div>
    </div> <!-- end of main -->
</div> <!-- end of main wrapper -->

<div id="templatemo_footer_wrapper">
	<div id="templatemo_footer">    
        <p><center><strong>Copyright © 2016</strong><strong><br />
        Yamaha Kebon Agung Motor</strong><strong><br />
		</strong></center></p>
    </div>
    
	<div class="cleaner"></div>
</div> <!-- end of templatemo_footer -->

</body>
</html>




<?php 
} 	  				
	else 
   		{
      		echo "<script>alert(' ANDA TIDAK MEMILIKI HAK AKSES');</script>";
	  		echo "<meta http-equiv=\"refresh\" content=\"1;url=home.php\">";
		}
?>