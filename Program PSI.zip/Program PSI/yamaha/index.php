<?php 	
		session_start();	
        if (!isset($_SESSION['username']))
		{
?>





<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Yamaha Kebon Agung Motor</title>
<meta name="keywords" content="blue, marble, design, theme, web, free templates, website templates, CSS, HTML" />
<meta name="description" content="Blue Marble Theme is a free website template provided by templatemo.com" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />

<link rel="stylesheet" href="nivo-slider.css" type="text/css" media="screen" />
<script src="js/jquery.min.js" type="text/javascript"></script>
<script src="js/jquery.nivo.slider.js" type="text/javascript"></script>

<script type="text/javascript">
$(window).load(function() {
	$('#slider').nivoSlider({
		effect:'random',
		slices:15,
		animSpeed:600,
		pauseTime:2400,
		startSlide:0, //Set starting Slide (0 index)
		directionNav:false, 
		directionNavHide:false, //Only show on hover
		controlNav:false, //1,2,3...
		controlNavThumbs:false, //Use thumbnails for Control Nav
		pauseOnHover:true, //Stop animation while hovering
		manualAdvance:false, //Force manual transitions
		captionOpacity:0.7, //Universal caption opacity
		beforeChange: function(){},
		afterChange: function(){},
		slideshowEnd: function(){} //Triggers after all slides have been shown
	});
});
</script>
</head>
<body>

<div id="templatemo_header_wrapper">
	<div id="templatemo_header">
    
    	<div id="site_title">
            <div align="center"><a href="http://www.templatemo.com"><span><strong>Part _and_ Accessories</strong></span></a> </div>
    	</div> 
<!-- end of site_title -->
        
        <div id="social_box">
        	<a href="http://www.stumbleupon.com/" target="_blank"><img src="images/stumbleupon.png" alt="stumbleupon" /></a>
            <a href="http://digg.com/" target="_blank"><img src="images/digg.png" alt="digg" /></a>
            <a href="http://www.facebook.com/" target="_blank"><img src="images/facebook.png" alt="facebook" /></a>
            <a href="https://twitter.com/" target="_blank"><img src="images/twitter.png" alt="twitter" /></a>
            <a href="http://feeds.feedburner.com/BasicBlogTips" target="_blank"><img src="images/feed.png" alt="feed" /></a>        </div>
        
<div id="templatemo_menu">
            <ul>
                <li><a href="index.php" class="current">Home</a></li>
                
            </ul>    	
        </div> <!-- end of templatemo_menu -->
    
    </div> <!-- end of header -->
</div> <!-- end of header wrapper -->

<div id="templatemo_main_wrapper">
	<div id="templatemo_main">
    
    	<div id="templatemo_content">
        
        	<div id="homepage_slider">
                 <div id="slider">
                     <a href="#"><img src="images/slideshow/01.jpg" alt="Image 1" title="Yamaha Kebon Agung Motor." /></a>
                     <a href="#"><img src="images/slideshow/02.jpg" alt="Image 2" title="Yamaha Kebon Agung Motor." /></a>
                     <a href="#"><img src="images/slideshow/03.jpg" alt="Image 3" title="Yamaha Kebon Agung Motor." /></a>
                     <a href="#"><img src="images/slideshow/04.jpg" alt="Image 4" title="Yamaha Kebon Agung Motor. " /></a>
                     <a href="#"><img src="images/slideshow/05.jpg" alt="Image 5" title="Yamaha Kebon Agung Motor. " /></a>
                </div>
		  </div>
                	
        	<div class="post_box">
        		<a href="#"><img src="images/templatemo_image_01.jpg" alt="Image 1" /></a>
          <div class="post_box_right">
            <h2>Yamaha To Celebrate 50 Years Of GP Racing</h2>
					<div class="post_meta"><strong>Date:</strong> May 28, 2011</div>
                    <p>Race fans attending this year’s Motorcycle Live should definitely   schedule a stop at the Yamaha stand – the manufacturer will be   celebrating 50 years of Grand Prix road racing with a 415 square metre   display of machinery representing five decades on the track.</p>
            			</div>
                <div class="cleaner"></div>
            </div>
            
            </div>
    	<div id="templatemo_sidebar">
        	<div class="sidebar_box"><img src="images/templatemo_ads.png" width="250" height="250" /></div>  
        	
            
            
<div class="sidebar_box">
            <h2 align="left"><strong>Login</strong></h2>
                <form id="form1" name="form1" method="post" action="validasi.php">
            		<p>Username </p>
            	  		<label>
            	  		<input type="text" name="username" id="username" />
            	  		</label>      	        
            		<p>&nbsp;</p>
            		<p>Password </p>        
                  		<label>
                  		<input type="password" name="password" id="password" />
                  		</label>         
                	<p>&nbsp;</p>            
            			<label>
            			<input type="submit" name="button" id="button" value="Login" />
            			</label>
                </form>
</div>
            
            
            
            </div>
    	<div class="cleaner"></div>
    </div> <!-- end of main -->
</div> <!-- end of main wrapper -->


<div id="templatemo_footer_wrapper">
	<div id="templatemo_footer">    
        <p><center><strong>Copyright © 2016</strong><strong><br />
        Yamaha Kebon Agung Motor</strong><strong><br />
		</strong></center></p>
    </div>
    
	<div class="cleaner"></div>
</div> <!-- end of templatemo_footer -->


</body>
</html>





<?php		
	}  
	else{
	header("Location:home.php");
	}
?>
