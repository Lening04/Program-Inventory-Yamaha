//We've included ../Includes/FusionCharts.php, which contains functions
//to help us easily embed the charts.
<?
include("Includes/FusionCharts.php");
?>
<HTML>
<HEAD>
   <TITLE> FusionCharts Free - dataURL and Database Example</TITLE>
   <SCRIPT LANGUAGE="Javascript" SRC="js/FusionCharts.js"></SCRIPT>
</HEAD>
<BODY>
   <?php
   //In this example, we show how to connect FusionCharts to a database
   //using dataURL method. In our previous example, we've used dataXML method
   //where the XML is generated in the same page as chart. Here, the XML data
   //for the chart would be generated in PieData.php.

   //For the sake of ease, we've used an an MySQL databases containing two
   //tables.

   //the php script in piedata.php interacts with the database,
   //converts the data into proper XML form and finally
   //relays XML data document to the chart
   $strDataURL = "PieData.php";

   //Create the chart - Pie 3D Chart with dataURL as strDataURL
   echo renderChart("swf/FCF_Pie3D.swf", $strDataURL, "", "FactorySum", 650, 450);
?>
</BODY>
</HTML>