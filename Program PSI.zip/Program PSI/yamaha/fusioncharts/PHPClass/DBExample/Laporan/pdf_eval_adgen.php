<?php
define('FPDF_FONTPATH','fpdf/font/');
require('fpdf/fpdf_protection.php');

include"sambung.php";
db_connect();

$ID_AGEN=$_GET["ID_AGEN"];




$query = mysql_query ("select t.TGL_TRANSAKSI_AGEN,t.ID_TRANSAKSI_AGEN,a.NAMA_AGEN,t.TOTAL_TRANSAKSI,s.KETERANGAN
from transaksi_agen t,agen a,detail_status d,status_agen s
where a.ID_AGEN = t.ID_AGEN and a.ID_AGEN='$ID_AGEN' and d.ID_STATUS_AGEN = s.ID_STATUS_AGEN and a.ID_AGEN = d.ID_AGEN");




define('FPDF_FONTPATH','fpdf/font/');
require('fpdf/fpdf.php');


class PDF extends FPDF_Protection {
var $col=0;
var $y0;

	function Header() {
		$this->Cell(19,0.5, '','B',0,'C'); //garis
		$this->Ln(0.3);
	    $this->Image('../../../../../images/logo.jpg',1,2.3,3);
		$this->SetFont('courier','B',20);
		$this->SetTextColor(0,0,0);
		$this->Cell(22,2, 'PT. THERABUANA','0',0,'C');
		$this->Ln(0.8);
		$this->SetFont('courier','B',16);
		$this->Cell(22,2,' Partner Travel Anda ',		'0',0,'C');
		$this->Ln(0.8);
		$this->SetFont('courier','B',14);
		$this->Cell(22,2,'  Jl. Kedung cowek 47 c, Suramadu, Surabaya  ',	'0',0,'C');
		$this->Ln(0.8);
		$this->SetFont('courier','B',13);
		$this->Cell(22,2,'  Telp : 031-3727777, 031-37287777',		'0',0,'C');
		$this->Ln(0.3);
		$this->Cell(19,1.5, '','B',0,'C'); //garis
		$this->Ln();
		$this->SetFont('courier','B',20);
		$this->SetTextColor(0,100,0);
		$this->Cell(19,2.5,' Laporan Evaluasi Agen ','0',0,'C');
		$this->Ln(2);
	}

	function Footer() {
		$this->SetY(-2);
		$this->Cell(19,0.5, '','B',0,'C'); //garis
		$this->SetY(-1.5);
		$this->SetFont('times','I',9);
		$this->Cell(0,1,'Halaman '.$this->PageNo().'/{nb}',0,0,'L');
		$y=date("Y");
		$d=date("d");
		$m=date("m");
		if($m=="01"){
		$b="Januari";}elseif($m=="02"){$b="Februari";}elseif($m=="03"){$b="Maret";}elseif($m=="04"){$b="April";
		}elseif($m=="05"){$b="Mei";}elseif($m=="06"){$b="Juni";}elseif($m=="07"){$b="Juli";}elseif($m=="08"){
		$b="Agustus";}elseif($m=="09"){$b="September";}elseif($m=="10"){$b="Oktober";}elseif($m=="11"){
		$b="Nopember";}else{$b="Desember";}
		$hari_ini="$d $b $y";	
		$this->SetFont('times','I',9);
		$this->Cell(0,1,'Tanggal Cetak : '.$hari_ini,0,0,'R');
	} 
}

$pdf=new PDF('P','cm','A4');
$pdf->SetProtection(array());
$pdf->Open();
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('courier','B',20);
$pdf->Ln(1);
$pdf->SetFont('times','B',11);
$pdf->SetFillcolor(230,230,230);
$pdf->SetTextcolor(0);
//$pdf->SetDrawcolor(128,0,0);
$pdf->Cell(1,0,'','0',0,'C');
{
$pdf->Cell(1,1,'No','1',0,'C',1);
$pdf->Cell(3,1,'TGl Transaksi','1',0,'C',1);
$pdf->Cell(3,1,'NO Transaksi','1',0,'C',1);
$pdf->Cell(4,1,'Franchise','1',0,'C',1);
$pdf->Cell(4,1,'Status Franchise','1',0,'C',1);
$pdf->Cell(3,1,'Total Transaksi','1',0,'C',1);
}
$pdf->Ln();
$pdf->SetFont('times','',11);
$i=1;
$totalpem=0;
while($get = mysql_fetch_array($query))
{
$pdf->Cell(1,0,'','0',0,'C');{
$pdf->Cell(1, 1, $i, 1, '0', 'C', $fill);
//------Explode tanggal------//
			$tgl=$get['TGL_TRANSAKSI_AGEN'];
			$a=$get['TGL_TRANSAKSI_AGEN'];
			$d=explode("-",$a);
			$TGL=$d[2]."-".$d[1]."-".$d[0];
$pdf->Cell(3, 1, $TGL, 1, '0', 'C', $fill);
$pdf->Cell(3, 1, $get[ID_TRANSAKSI_AGEN], 1, '0', 'C', $fill);
$pdf->Cell(4, 1, $get[NAMA_AGEN], 1, '0', 'C', $fill);
$pdf->Cell(4, 1, $get[KETERANGAN], 1, '0', 'C', $fill);
$totalpem = $totalpem + $get[TOTAL_TRANSAKSI];
$pdf->Cell(3, 1,number_format($get[TOTAL_TRANSAKSI],2,',','.'), 1, '0', 'C', $fill);

$pdf->Ln();
$i++;
$fill = !$fill;
} }
$pdf->Cell(1,0,'','0',0,'C');
$pdf->Cell(14.5,1,'Jumlah Total Transaksi',1,0,'C');
$pdf->SetFont('times','B',11);
//$tot=number_format($total,2,',','.');
$totalpem=number_format($totalpem,2,',','.');
$pdf->Cell(3.5,1,$totalpem,1,0,'C');  
  $pdf->Output();
   
?> 