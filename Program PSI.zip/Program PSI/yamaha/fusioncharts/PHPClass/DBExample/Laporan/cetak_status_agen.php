<?php
include"sambung.php";
 


db_connect();
$VALIDASI_AGEN = $_REQUEST['VALIDASI_AGEN'];

$query=mysql_query("SELECT a.*,k.NM_KOTA
FROM agen a,kota k
WHERE a.VALIDASI_AGEN = '$VALIDASI_AGEN' and k.ID_KOTA = a.ID_KOTA
ORDER BY VALIDASI_AGEN ASC");
								

 
define('FPDF_FONTPATH','fpdf/font/');
require('fpdf/fpdf_protection.php');

class PDF extends FPDF_Protection {
var $col=0;
var $y0;

	function Header() {
		$this->Cell(19,0.5, '','B',0,'C'); //garis
		$this->Ln(0.3);
	    $this->Image('../../../../../images/logo.jpg',1,2.3,3);
		$this->SetFont('courier','B',20);
		$this->SetTextColor(0,0,0);
		$this->Cell(22,2, 'PT. THERABUANA','0',0,'C');
		$this->Ln(0.8);
		$this->SetFont('courier','B',16);
		$this->Cell(22,2,'  Partner Travel Anda ',		'0',0,'C');
		$this->Ln(0.8);
		$this->SetFont('courier','B',14);
		$this->Cell(22,2,' Jl. Kedung cowek 47 c, Suramadu, Surabaya',		'0',0,'C');
		$this->Ln(0.8);
		$this->SetFont('courier','B',13);
		$this->Cell(22,2,'Telp : 031-3727777, 031-37287777',		'0',0,'C');
		$this->Ln(0.3);
		$this->Cell(19,1.5, '','B',0,'C'); //garis
		$this->Ln();
		$this->SetFont('courier','B',20);
		$this->SetTextColor(0,100,0);
		$this->Cell(19,2.5,' Laporan Validasi Status AGen ','0',0,'C');
		$this->Ln(2);
	}

	function Footer() {
		$this->SetY(-2);
		$this->Cell(19,0.5, '','B',0,'C'); //garis
		$this->SetY(-1.5);
		$this->SetFont('times','I',9);
		$this->Cell(0,1,'Halaman '.$this->PageNo().'/{nb}',0,0,'L');
		$y=date("Y");
		$d=date("d");
		$m=date("m");
		if($m=="01"){
		$b="Januari";}elseif($m=="02"){$b="Februari";}elseif($m=="03"){$b="Maret";}elseif($m=="04"){$b="April";
		}elseif($m=="05"){$b="Mei";}elseif($m=="06"){$b="Juni";}elseif($m=="07"){$b="Juli";}elseif($m=="08"){
		$b="Agustus";}elseif($m=="09"){$b="September";}elseif($m=="10"){$b="Oktober";}elseif($m=="11"){
		$b="Nopember";}else{$b="Desember";}
		$hari_ini="$d $b $y";	
		$this->SetFont('times','I',9);
		$this->Cell(0,1,'Tanggal Cetak : '.$hari_ini,0,0,'R');
	} 
}

$pdf=new PDF('P','cm','A4');
$pdf->SetProtection(array());
$pdf->Open();
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('courier','B',20);
$pdf->Ln(1);
$pdf->SetFont('times','B',11);
$pdf->SetFillcolor(230,230,230);
$pdf->SetTextcolor(0);
//$pdf->SetDrawcolor(128,0,0);
{
$pdf->Cell(1,1,'No','1',0,'C',1);
$pdf->Cell(4,1,'Nama','1',0,'C',1);
$pdf->Cell(3.5,1,'Kota','1',0,'C',1);
$pdf->Cell(5,1,'Alamat','1',0,'C',1);
$pdf->Cell(3,1,'No Telp/HP','1',0,'C',1);
$pdf->Cell(3,1,'Validasi','1',0,'C',1);}
$pdf->Ln();
$pdf->SetFont('times','',11);
$i=1;
while($get = mysql_fetch_array($query))
{
$pdf->Cell(1, 1, $i, 1, '0', 'C', $fill);
$pdf->Cell(4, 1, $get[NAMA_AGEN], 1, '0', 'L', $fill);
$pdf->Cell(3.5, 1, $get[NM_KOTA], 1, '0', 'C', $fill);
$pdf->Cell(5, 1, $get[ALAMAT_AGEN], 1, '0', 'L', $fill);
$pdf->Cell(3, 1, $get[TELP_NO_HP], 1, '0', 'L', $fill);
//===========STATUS KEANGGOTAAN=========//
			
			if($get[VALIDASI_AGEN]=='0')
			{
				$aaa = "Calon Franchisee" ;
			
			}
			elseif($get[VALIDASI_AGEN]=='1')
			{
				$aaa = "Sementara" ;
						}
			elseif($get[VALIDASI_AGEN]=='2')
			{
				$aaa = "Franchisee" ;
						}
$pdf->Cell(3, 1, $aaa, 1, '0', 'L', $fill);
$pdf->Ln();
$i++;
$fill = !$fill;
}
  $pdf->Output(); 
?> 