<?php
include"sambung.php";
 


db_connect();
$ID_PENDAFTARAN_AGEN= $_GET['ID_PENDAFTARAN_AGEN'];

$query=mysql_fetch_array(mysql_query("SELECT *
FROM pendaftaran_agen p, agen a, kota k, propinsi r
WHERE p.ID_AGEN = a.ID_AGEN
AND a.ID_KOTA = k.ID_KOTA
and k.ID_PROPINSI = r.ID_PROPINSI
and p.ID_PENDAFTARAN_AGEN = '$ID_PENDAFTARAN_AGEN'
ORDER BY p.TGL_PENDAFTARAN ASC"));
								

 
  
  
define('FPDF_FONTPATH','fpdf/font/');
require('fpdf/fpdf_protection.php');

class PDF extends FPDF_Protection {
var $col=0;
var $y0;

	function Header() {
		$this->Cell(19,0.5, '','B',0,'C'); //garis
		$this->Ln(0.3);
	    $this->Image('../../../../../images/logo.jpg',1,2.3,3);
		$this->SetFont('courier','B',20);
		$this->SetTextColor(0,0,0);
		$this->Cell(22,2, 'IDENTITAS FRANCHISEE','0',0,'C');
		$this->Ln(0.8);
		$this->SetFont('courier','B',16);
		$this->Cell(22,2,'  PT. THERABUANA Partner Travel Anda ',		'0',0,'C');
		$this->Ln(0.8);
		$this->SetFont('courier','B',14);
		$this->Cell(22,2,' Jl. Kedung cowek 47 c, Suramadu, Surabaya',		'0',0,'C');
		$this->Ln(0.8);
		$this->SetFont('courier','B',13);
		$this->Cell(22,2,'Telp : 031-3727777, 031-37287777',		'0',0,'C');
		$this->Ln(0.3);
		$this->Cell(19,1.5, '','B',0,'C'); //garis
		$this->Ln();
		
	
	}

	function Footer() {
		$this->SetY(-2);
		$this->Cell(19,0.5, '','B',0,'C'); //garis
		$this->SetY(-1.5);
		$this->SetFont('times','I',9);
		$this->Cell(0,1,'Halaman '.$this->PageNo().'/{nb}',0,0,'L');
		$y=date("Y");
		$d=date("d");
		$m=date("m");
		if($m=="01"){
		$b="Januari";}elseif($m=="02"){$b="Februari";}elseif($m=="03"){$b="Maret";}elseif($m=="04"){$b="April";
		}elseif($m=="05"){$b="Mei";}elseif($m=="06"){$b="Juni";}elseif($m=="07"){$b="Juli";}elseif($m=="08"){
		$b="Agustus";}elseif($m=="09"){$b="September";}elseif($m=="10"){$b="Oktober";}elseif($m=="11"){
		$b="Nopember";}else{$b="Desember";}
		$hari_ini="$d $b $y";	
		$this->SetFont('times','I',9);
		$this->Cell(0,1,'Tanggal Cetak : '.$hari_ini,0,0,'R');
	} 
}

$pdf=new PDF('P','cm','A4');
$pdf->Open();
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->Ln();
//$pdf->SetDrawcolor(128,0,0);

//------Explode tanggal------//
			$tgl=$query['TGL_PENDAFTARAN'];
			$a=$query['TGL_PENDAFTARAN'];
			$d=explode("-",$a);
			$TGL_PENDAFTARAN=$d[2]."-".$d[1]."-".$d[0];

		  	 if (  $query["JENIS_KELAMIN_AGEN"]=="L")
				{$j="Laki-Laki";}
			 else
				{$j="Perempuan";}

			 //------Explode tanggal------//
				$tgl=$query["TGL_LAHIR_AGEN"];
				$a=$query["TGL_LAHIR_AGEN"];
				$d=explode("-",$a);
				$TGL_LAHIR=$d[2]."-".$d[1]."-".$d[0];
				
	 			if ( $query["VALIDASI_AGEN"]=="0")
					{$k="Calon Agen";}
				 elseif($query["VALIDASI_AGEN"]=="1")
					{$k="Agen Sementara";}
				else
					{$k="Agen ";}

$pdf->Cell(6,1,'TGl Daftar',0,0,'L');
$pdf->Cell(4, 1,':   '. $TGL_PENDAFTARAN,0,0,'L');
$pdf->Ln();
$pdf->Cell(6,1,'ID Pendaftaran',0,0,'L');
$pdf->Cell(4, 1, ':   '.$query["ID_PENDAFTARAN_AGEN"],0,0,'L');
$pdf->Ln();
$pdf->Cell(6,1,'Nama',0,0,'L');
$pdf->Cell(4, 1, ':   '.$query["NAMA_AGEN"],0,0,'L');
$pdf->Ln();
$pdf->Cell(6,1,'NO Identitas',0,0,'L');
$pdf->Cell(4, 1, ':   '.$query["NO_IDENTITAS_AGEN"],0,0,'L');
$pdf->Ln();
$pdf->Cell(6,1,'Jenis Kelamin ',0,0,'L');
$pdf->Cell(4, 1, ':   '.$j,0, '0', 'L');
$pdf->Ln();
$pdf->Cell(6,1,'Tgl Lahir ',0,0,'L');
$pdf->Cell(4, 1, ':   '.$TGL_LAHIR,0,0,'L');
$pdf->Ln();
$pdf->Cell(6,1,'Alamat ',0,0,'L');
$pdf->Cell(4, 1, ':   '.$query["ALAMAT_AGEN"],0,0,'L');
$pdf->Ln();
$pdf->Cell(6,1,'KoDe Pos',0,0,'L');
$pdf->Cell(4, 1, ':   '.$query["KODE_POS_AGEN"],0,0,'L');
$pdf->Ln();
$pdf->Cell(6,1,'Kota',0,0,'L');
$pdf->Cell(4, 1, ':   '.$query["NM_KOTA"],0,0,'L');
$pdf->Ln();
$pdf->Cell(6,1,'Propinsi',0,0,'L');
$pdf->Cell(4, 1, ':   '.$query["NAMA_PROPINSI"],0,0,'L');
$pdf->Ln();
$pdf->Cell(6,1,'tELP/nO hP',0,0,'L');
$pdf->Cell(4, 1, ':   '.$query["TELP_NO_HP"],0,0,'L');
$pdf->Ln();
$pdf->Cell(6,1,'Email',0,0,'L');
$pdf->Cell(4, 1, ':   '.$query["ALAMAT_EMAIL_AGEN"],0,0,'L');
$pdf->Ln();
$pdf->Cell(6,1,'Website',0,0,'L');
$pdf->Cell(4, 1, ':   '.$query["WEBSITE_AGEN"],0,0,'L');
$pdf->Ln();
$pdf->Cell(6,1,'No Rekening',0,0,'L');
$pdf->Cell(4, 1, ':   '.$query["NO_REKENING_AGEN"],0,0, 'L');
$pdf->Ln();
$pdf->Cell(6,1,'Validasi Status Agen',0,0,'L');
$pdf->Cell(4, 1, ':   '.$k,0,0,'L');
$pdf->Ln();
$namafoto = $query['UPLOAD_NO_REKENING'];
$dir = "../bukti/".$namafoto;		
$foto= $item['UPLOAD_IDENTITAS_DIRI'];
$dir2 = "../bukti/".$foto;				
$pdf->Cell(6,1,'Bukti No Rekening',0,0,'L');
$pdf->Cell(4, 1, ':   '.$dir,0,0,'L');
$pdf->Ln();
$pdf->Cell(6,1,'Bukti Identitas Diri',0,0,'L');
$pdf->Cell(4, 1, ':   '.$dir,0,0,'L');
$pdf->Ln();
$pdf->SetFont('times','',11);
$pdf->Ln();
  $pdf->Output(); 
?> 