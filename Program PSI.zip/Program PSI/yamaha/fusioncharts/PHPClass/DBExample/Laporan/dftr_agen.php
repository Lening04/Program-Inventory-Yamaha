<?php 
	include "sambung.php";
require_once ("../../../../../Master/tgl.php"); 
	
	$num = $_GET['num'];//Get the numeration of the page 
	if(empty($num)){//if the numeration is empty 
		$num = 1;//the numeration is 1 
		$no = 1;
	}else{
		$no = 9*($num-1)+$num;
	} 
	$limit = 10;//Sets the limit of results to display in each page, change if you want. 
	$start = ($num-1)*$limit; 
	$start = round($start,0);//rounds the result 
	//lets make a loop and get all news from the database
	
	$tahun=$_GET["thn"];
    $bulan=$_GET["bln"];
    $tgl=$_GET["tgl"];
	
	$act = "cetak";
	db_connect();
	$sql1 = "SELECT p.TGL_PENDAFTARAN, a.ID_AGEN,a.NO_IDENTITAS_AGEN, a.NAMA_AGEN, 
	a.JENIS_KELAMIN_AGEN,  a.ALAMAT_AGEN, k.NM_KOTA, a.TELP_NO_HP, a.VALIDASI_AGEN
					FROM pendaftaran_agen p, agen a, kota k
					WHERE p.ID_AGEN = a.ID_AGEN
					AND a.ID_KOTA = k.ID_KOTA
					ORDER BY a.VALIDASI_AGEN ASC";	
	
	$tab = "<td colspan=\"2\" align=\"left\"><table width=\"40%\">
          <tr>
            <td>&nbsp;</td>
            <td><div align=\"center\">Mengetahui<br />
            (........)</div></td>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			
          </tr>
        </table>	      </td>";

	if (! $res1=@mysql_query($sql1))
	 {
	  echo "data error !";
	  return 0;
	 }
	 
	 switch ($bulan)
		{
			case 1: 
			$bln = "Januari"; 
			break;
			case 2: 
			$bln = "Februari"; 
			break;
		    case 3: 
			$bln = "Maret"; 
			break;
			case 4: 
			$bln = "April"; 
			break;
			case 5: 
			$bln = "Mei"; 
			break;
			case 6: 
			$bln = "Juni"; 
			break;
			case 7: 
			$bln = "Juli"; 
			break;
			case 8: 
			$bln = "Agustus"; 
			break;
		    case 9: 
			$bln = "September"; 
			break;
			case 10: 
			$bln = "Oktober"; 
			break;
			case 11: 
			$bln = "November"; 
			break;
			case 12: 
			$bln = "Desember"; 
			break;
		}

	
	$judul = "Rekapitulasi Daftar Franchisee <?php echo $tanggal; ?>";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Sistem Informasi Pendaftaran Franchisee PT. Therabuana Surabaya</title>
<style type="text/css">
<!--
.style5 {font-size: 16px; font-family: Geneva, Arial, Helvetica, sans-serif; }
.style7 {
	font-weight: bold;
	font-size: 14px;
}
.style8 {
	font-weight: bold;
	font-size: 14px;
}
.style9 {
	font-weight: bold;
	font-size: 14px;
}
.style10 {
	font-weight: bold;
	font-size: 14px;
}
-->
</style>
</head>

<body onLoad="window.print();" background="">
<table width="75%" border="1" bordercolor="#000000" align="center" bgcolor="#FFFFFF">
 
    <td class="style3"><table width="100%">
	  <tr>
  
    <td height="11" colspan="3" align="center" class="style11"><strong>
	<table width="91" height="81" border="0" align="left" background="../../../../../images/logo.gif">
        <tr>
          <td width="93" height="25">&nbsp;</td>
        </tr>
      </table>
      PT. THERABUANA <br />
			Partner Travel Anda<br/>
			</strong>
      
      <strong>Jl. Kedung cowek 47 c, Suramadu, Surabaya<br />
			Telp : 031-3727777, 031-37287777</strong></td>
    </tr>
	  <tr>
		<td colspan="12"><hr />
		  <p align="center"><strong><span class="style21"><?php echo $judul ?></span></strong></p>
		  <p>
		<table width="90%" border="1" cellpadding="1" cellspacing="1" align="center" background="">
          <tr>
            <th colspan="12" bordercolor="#000066" bgcolor="#FFFFFF"> <span class="style5">&nbsp;&nbsp;<span class="style5">DAFTAR FRANCHISEE</span> </span></th>
          </tr>
          <tr>
            <td width="5%" rowspan="2" bordercolor="#000066" bgcolor="#0099FF" class="style7"><div align="center" class="style21">No.</div></td>
			<td bordercolor="#000066" bgcolor="#0099FF" class="style7"><div align="center" class="style21">TANGGAL DAFTAR </div>              </td>
            <td bordercolor="#000066" bgcolor="#0099FF" class="style7"><div align="center" class="style21">ID FRANCHISEE </div>              </td>
			  <td bordercolor="#000066" bgcolor="#0099FF" class="style7"><div align="center" class="style21">NO IDENTITAS</div>              </td>
				  <td bordercolor="#000066" bgcolor="#0099FF" class="style9"><div align="center" class="style21">FRANCHISEE </div>              </td>
				  <td bordercolor="#000066" bgcolor="#0099FF" class="style9"><div align="center" class="style21">JENIS KELAMIN</div>              </td>
				  <td bordercolor="#000066" bgcolor="#0099FF" class="style9"><div align="center" class="style21">ALAMAT</div>              </td>
				  <td bordercolor="#000066" bgcolor="#0099FF" class="style9"><div align="center" class="style21">KOTA</div>              </td>
				  <td bordercolor="#000066" bgcolor="#0099FF" class="style9"><div align="center" class="style21">TELEPON</div>              </td>
				  <td bordercolor="#000066" bgcolor="#0099FF" class="style9"><div align="center" class="style21">STATUS KEANGGOTAAN</div>              </td>
				  
          </tr>
          <tr>          </tr>
	<?php	  
	//$tahun=$_GET["thn"];
    //$bulan=$_GET["bulan"];
    //$tgl=$_GET["tgl"];
		  //echo $tgl."-".$bulan."-".$tahun;
		  $tot=0;
 $acQuery = mysql_query("SELECT p.TGL_PENDAFTARAN, a.ID_AGEN,a.NO_IDENTITAS_AGEN, a.NAMA_AGEN, 
	a.JENIS_KELAMIN_AGEN,  a.ALAMAT_AGEN, k.NM_KOTA, a.TELP_NO_HP, a.VALIDASI_AGEN
					FROM pendaftaran_agen p, agen a, kota k
					WHERE p.ID_AGEN = a.ID_AGEN
					AND a.ID_KOTA = k.ID_KOTA
					ORDER BY a.VALIDASI_AGEN ASC LIMIT $start, $limit");
		 
		  $cont = 0;
		  while($uRow=mysql_fetch_array($acQuery)){
		  		
		  $id=$uRow['ID_AGEN'];
		  $nama=$uRow['NAMA_AGEN'];
		  $alamat=$uRow['ALAMAT_AGEN'];
		  $kota=$uRow['NM_KOTA'];

		  
		  //------Explode tanggal------//
$tgl=$uRow['TGL_PENDAFTARAN'];
		$a=$uRow['TGL_PENDAFTARAN'];
		$d=explode("-",$a);
		$TGL_DAFTAR=$d[2]."-".$d[1]."-".$d[0];
		
		 //===========STATUS KEANGGOTAAN=========//
			
			if($uRow[VALIDASI_AGEN]=='0')
			{
				$aaa = "Calon Franchisee" ;
			
			}
			elseif($uRow[VALIDASI_AGEN]=='1')
			{
				$aaa = "Proses" ;
						}
			elseif($uRow[VALIDASI_AGEN]=='2')
			{
				$aaa = "Franchisee" ;
						}
			$cont++;
			if($cont % 2 == 0)
			{
				
				$bgColor = "#EEEEEE" ;
			}
			else
			{
				$bgColor = "#FFFFFF" ;
			}
			
		?>	
          <tr bgcolor="<?php echo $bgColor; ?>">
		 
            <td bordercolor="#000066"><div align="center"><?php echo $no; ?></div></td>
			<td bordercolor="#000066"><div align="center"><?php echo $TGL_DAFTAR; ?></div></td>
			 <td bordercolor="#000066"><div align="center"><?php echo $id; ?></div></td>
			 <td bordercolor="#000066"><div align="center"><?php echo $uRow['NO_IDENTITAS_AGEN']?></div></td>
			 <td bordercolor="#000066"><div align="center"><?php echo $nama ?></div></td>
			 <? 
		  	 if ($uRow['JENIS_KELAMIN_AGEN']=="L")
				{$j="Laki-Laki";}
			 else
				{$j="Perempuan";}
		  ?>
			 <td bordercolor="#000066"><div align="center"><?php echo $j; ?></div></td>
			 <td bordercolor="#000066"><div align="center"><?php echo $alamat ?></div></td>
			 <td bordercolor="#000066"><div align="center"><?php echo $kota ?></div></td>
			 <td bordercolor="#000066"><div align="center"><?php echo $uRow['TLP_NO_HP'] ?></div></td>
			<td bordercolor="#000066"><div align="center"><?php echo $aaa ?></div></td>
          </tr>
	 <?php 
		$no++;
		}	
		?>
          <?php
		  $k=$no - 1;
			echo"<tr bordercolor='#FFFFFF'><td colspan=3><div align='left'><b><font class='m1'>Jumlah Franchisee : </font></b></td>
			<td colspan=10><div align='left'><b><font class='m1'>$k</font></b></td></tr>";
			$kyQuery = mysql_query("SELECT p.TGL_PENDAFTARAN, a.ID_AGEN,a.NO_IDENTITAS_AGEN, a.NAMA_AGEN, 
	a.JENIS_KELAMIN_AGEN,  a.ALAMAT_AGEN, k.NM_KOTA, a.TELP_NO_HP, a.VALIDASI_AGEN
					FROM pendaftaran_agen p, agen a, kota k
					WHERE p.ID_AGEN = a.ID_AGEN
					AND a.ID_KOTA = k.ID_KOTA
					ORDER BY a.VALIDASI_AGEN ASC" );//Get the total number of results
			$totalpages = ceil(mysql_num_rows($kyQuery)/$limit);
			$c = 0;//The variable c is 0 
			echo "<br>";//make a <br> to separate the results from the [1][2]... 
			$kyQuery=mysql_query("SELECT p.TGL_PENDAFTARAN, a.ID_AGEN,a.NO_IDENTITAS_AGEN, a.NAMA_AGEN, 
	a.JENIS_KELAMIN_AGEN,  a.ALAMAT_AGEN, k.NM_KOTA, a.TELP_NO_HP, a.VALIDASI_AGEN
					FROM pendaftaran_agen p, agen a, kota k
					WHERE p.ID_AGEN = a.ID_AGEN
					AND a.ID_KOTA = k.ID_KOTA
					ORDER BY a.VALIDASI_AGEN ASC LIMIT $start, $limit");
			echo"<tr bordercolor='#FFFFFF'><td colspan=15><div align='left'><b><font class='m1'>Halaman : </font></b>";
			while($c<$totalpages)
			{//while c is < than the total pages 
			$page = $c + 1;//sets the variable $page as 0 + 1 = 1 
			if($_GET['num']==$page)
			{//Gets the number of the page and if its the same that the page 
			echo "[$page] ";//its only echoes the page, not the url to this page  
			}
			else
			{//else 
			echo "<a href=dftr_agen.php?num=$page>[$page] </a>";//it echoes the url to the page 
			} 
			$c =$c+1;
			} 
			echo"</div></td></tr>";
		
		?>
        </table>
	<TR>
	      <?php echo $tab; ?>		</TR>
		  </p></td>
	  </tr>
	  <tr>	  </tr>
	  <tr>
		<td>
		  Tanggal Cetak : <?php echo $tanggal; ?> <br />		</td>
	  </tr>
	</table>
  
  </table>

</body>
</html>
