<?
session_start();
include "sambung.php";
require_once ('../../../../../Master/tgl.php'); 
//include "../fungsi_cart.php";
if ($_SESSION['Login'] == "true")
{ 



?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" >
<head>
<title>Laporan  Pembeliaan Deposit AGen</title>
<link rel="stylesheet" type="text/css" href="default.css" media="screen" />
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="menu/menu.css" rel="stylesheet" type="text/css" />
		 
		
<meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
<style type="text/css">
<!--
.style1 {
	color: #B00000;
	font-weight: bold;
}
.style3 {color: #FFFFFF}
.style4 {color: #000000}
-->
</style>
</head>
</html>

<html xmlns="http://www.w3.org/1999/xhtml" >
<head>
</head>

<body background="" >  
	 <p>&nbsp;</p>
	 <form name="form4" method="GET" action="eval_adgen_nama.php" target="blank">
         
	    
	      <table width="800" border="0" align="center">
            
       </table>
	      <table width="450" height="50" border="2" align="center" cellpadding="3" cellspacing="3" bordercolor="#0099FF">
            <tr bordercolor="#0099FF" bgcolor="#0099FF">
              <td colspan="2"><div align="left" class="style6">
                  <div align="center" class="style8 style1 style3">EVALUASI	AGEN	BERDASARKAN NAMA AGEN </div>
              </div></td>
            </tr>
      </table>
	      <table width="450" height="78" border="3" align="center" cellpadding="3" cellspacing="3" bordercolor="#0099FF" bgcolor="#FFFFFF">
						
					<tr>
                                        <td><table width="100%"  border="0">
                                            <tr>
                                 
                                              <td width="33%" align="center"><span class="style4">Pilih Nama Agen  :
                                                 <select name="ID_AGEN" id="ID_AGEN">
												 <option value="0"> Pilih Nama
					  		    <?php
								db_connect();
								$query=mysql_query("SELECT * from agen where VALIDASI_AGEN='2' group by VALIDASI_AGEN");
						       	
				 		         while($row= mysql_fetch_row($query))
						        {
									echo "<option value=".$row[0].">".$row[6]."</option>\n";
								}
							    ?></option>
                      </select>
                                              </span></td>
                                            </tr>
                                        </table></td>
            </tr>
                                      <tr>
                                        <td><div align="center">
                                            <input name="Submit" type="submit" class="csskuCopy" value="Lihat / Cetak  ">
                                        </div></td>
                                      </tr>
      </table>
</form>

	 <td width="4%">&nbsp;</td>
                                </tr>
                                <tr>
                                  <td>&nbsp;</td>
                                  <td>                                
                                  <td>&nbsp;</td>
                                </tr>
								<form name="form2" method="GET" action="eval_bln.php" target="_blank">
								
								  <table width="450" height="50" border="2" align="center" cellpadding="3" cellspacing="3" bordercolor="#0099FF">
                                    <tr bordercolor="#0099FF" bgcolor="#FFFFFF">
                                      <td colspan="2" bordercolor="#0099FF" bgcolor="#0099FF"><div align="left" class="style6">
                                          <div align="center" class="style8 style1 style3"> EVALUASI AGEN MASUK BULANAN </div>
                                      </div></td>
                                    </tr>
                                  </table>
								  <table width="450" height="78" border="3" align="center" cellpadding="3" cellspacing="3" bordercolor="#0099FF" bgcolor="#FFFFFF">
					 <tr >
                                        <td height="30" align="center" bgcolor="#FFFFFF"><div align="center">
                                          <table width="100%"  border="0">
                                            <tr>
                                              <td><span class="style4">Bulan :</span>
                                                <span class="style4">
                                                <select name="bulan"  id="bulan" onchange="showUser(this.value)">
                                                  <option>-- Pilih --</option>
                                                  <option value="1">Januari</option>
                                                  <option value="2">Februari</option>
                                                  <option value="3">Maret</option>
                                                  <option value="4">April</option>
                                                  <option value="5">Mei</option>
                                                  <option value="6">Juni</option>
                                                  <option value="7">Juli</option>
                                                  <option value="8">Agustus</option>
                                                  <option value="9">September</option>
                                                  <option value="10">Oktober</option>
                                                  <option value="11">November</option>
                                                  <option value="12">Desember</option>
                                                </select>
                                              </span></td>
                                              <td><span class="style4">Tahun :
                                                <select name="thn" id="thn" >
												 <option>-- Pilih --</option>
                                                      <?
		  echo "<option value=''>----</option>";
			$tahun=(integer) date ("Y");
			for ($ithn_u=$tahun; $ithn_u>($tahun-5); $ithn_u--){
				if ($ithn_u==$thn_u) echo "<option value=$ithn_u selected>$ithn_u";
				else echo "<option value=$ithn_u>$ithn_u";
			}echo "</option>"
		  ?>
                                              </select>
                                              </span></td>
                                            </tr>
                                          </table>
                                        </div>                                          <div id="txtHint"></div></td>
            </tr>
                                      <tr align="center">
                                        <td bgcolor="#FFFFFF"><div align="center">
                                            <input name="Submit" type="submit" class="csskuCopy" value="Lihat / Cetak">
											<input name="Keluar" type="button" id="Keluar" onClick="location='../../../../../menu_direktur2.php'" value="Keluar"/>
                                        </div></td>
                                      </tr>
                                  </table>
</form>
                                </tr>
                                <tr>
                                  <td>&nbsp;</td>
                                  <td>                                
                                  <td>&nbsp;</td>
                                </tr>
                                  </div>
                                  </TD>
                                  </div>
                                  </div>
                                  </div>
                                  </div>
</body>
</html>
<?
}
else
{
 echo '<script language="javascript">window.alert("Anda belum Login.")</script>';
 echo '<meta http-equiv="Refresh" content="0; URL=index.php">';;
}
?> 