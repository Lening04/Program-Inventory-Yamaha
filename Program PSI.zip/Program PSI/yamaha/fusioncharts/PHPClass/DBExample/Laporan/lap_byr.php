<?
session_start();
include "sambung.php";
require_once ('../../../../../Master/tgl.php'); 
//include "../fungsi_cart.php";
if ($_SESSION['Login'] == "true")
{ 



?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" >
<head>
<title>Laporan Pembayaran Pembeliaan Deposit AGen</title>
<link rel="stylesheet" type="text/css" href="default.css" media="screen" />
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="menu/menu.css" rel="stylesheet" type="text/css" />
		 
		
<meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
<style type="text/css">
<!--
.style1 {
	color: #B00000;
	font-weight: bold;
}
.style3 {color: #FFFFFF}
.style4 {color: #000000}
-->
</style>
</head>
</html>

<html xmlns="http://www.w3.org/1999/xhtml" >
<head>
</head>

<body background="" >  
	 <p>&nbsp;</p>
	 <form name="form3" method="GET" action="pdf_byr_hari.php" target="blank">
         
	    
	      <table width="800" border="0" align="center">
            
       </table>
	      <table width="450" height="50" border="2" align="center" cellpadding="3" cellspacing="3" bordercolor="#0099FF">
            <tr bordercolor="#0099FF" bgcolor="#0099FF">
              <td colspan="2"><div align="left" class="style6">
                  <div align="center" class="style8 style1 style3">LAPORAN PEMBAYARAN MASUK HARIAN		 </div>
              </div></td>
            </tr>
      </table>
	      <table width="450" height="78" border="3" align="center" cellpadding="3" cellspacing="3" bordercolor="#0099FF" bgcolor="#FFFFFF">
						
					<tr>
                                        <td><table width="100%"  border="0">
                                            <tr>
                                              <td width="25%"><span class="style4">Tgl :
                                                    <select name="tgl" size="1" id="tgl" >
													 <option>-- Pilih --</option>
                                                      <option value="01">01</option>
                                                      <option value="02">02</option>
                                                      <option value="03">03</option>
                                                      <option value="04">04</option>
                                                      <option value="05">05</option>
                                                      <option value="06">06</option>
                                                      <option value="07">07</option>
                                                      <option value="08">08</option>
                                                      <option value="09">09</option>
                                                      <option value="10">10</option>
                                                      <option value="11">11</option>
                                                      <option value="12">12</option>
                                                      <option value="13">13</option>
                                                      <option value="14">14</option>
                                                      <option value="15">15</option>
                                                      <option value="16">16</option>
                                                      <option value="17">17</option>
                                                      <option value="18">18</option>
                                                      <option value="19">19</option>
                                                      <option value="20">20</option>
                                                      <option value="21">21</option>
                                                      <option value="22">22</option>
                                                      <option value="23">23</option>
                                                      <option value="24">24</option>
                                                      <option value="25">25</option>
                                                      <option value="26">26</option>
                                                      <option value="27">27</option>
                                                      <option value="28">28</option>
                                                      <option value="29">29</option>
                                                      <option value="30">30</option>
                                                      <option value="31">31</option>
                                                    </select>
                                              </span></td>
                                              <td width="35%"><span class="style4">Bulan :
                                                    <select name="bulan" size="1" id="bulan" >
													 <option>-- Pilih --</option>
                                                      <option value="1">Januari</option>
                                                      <option value="2">Februari</option>
                                                      <option value="3">Maret</option>
                                                      <option value="4">April</option>
                                                      <option value="5">Mei</option>
                                                      <option value="6">Juni</option>
                                                      <option value="7">Juli</option>
                                                      <option value="8">Agustus</option>
                                                      <option value="9">September</option>
                                                      <option value="10">Oktober</option>
                                                      <option value="11">Nopember</option>
                                                      <option value="12">Desember</option>
                                                    </select>
                                              </span></td>
                                              <td width="33%"><span class="style4">Tahun :
                                                    <select name="thn" id="thn" >
													 <option>-- Pilih --</option>
                                                    <?
		  echo "<option value=''>----</option>";
			$tahun=(integer) date ("Y");
			for ($ithn_u=$tahun; $ithn_u>($tahun-5); $ithn_u--){
				if ($ithn_u==$thn_u) echo "<option value=$ithn_u selected>$ithn_u";
				else echo "<option value=$ithn_u>$ithn_u";
			}echo "</option>"
		  ?>
                                                    </select>
                                              </span></td>
                                            </tr>
                                        </table></td>
            </tr>
                                      <tr>
                                        <td><div align="center">
                                            <input name="Submit" type="submit" class="csskuCopy" value="    Lihat / Cetak  ">
											<input name="Keluar" type="button" id="Keluar" onClick="location='../../../../../menu_direktur2.php'" value="Keluar"/>
                                        </div></td>
                                      </tr>
      </table>
</form>

	 <td width="4%">&nbsp;</td>
                                </tr>
                                <tr>
                                  <td>&nbsp;</td>
                                  <td>                                
                                  <td>&nbsp;</td>
                                </tr>
								<form name="form1" method="GET" action="pdf_byr_bln.php" target="_blank">
								
								  <table width="450" height="50" border="2" align="center" cellpadding="3" cellspacing="3" bordercolor="#0099FF">
                                    <tr bordercolor="#0099FF" bgcolor="#FFFFFF">
                                      <td colspan="2" bordercolor="#0099FF" bgcolor="#0099FF"><div align="left" class="style6">
                                          <div align="center" class="style8 style1 style3">LAPORAN PEMBAYARAN MASUK BULANAN </div>
                                      </div></td>
                                    </tr>
                                  </table>
								  <table width="450" height="78" border="3" align="center" cellpadding="3" cellspacing="3" bordercolor="#0099FF" bgcolor="#FFFFFF">
			
			
					 
					
					
					 <tr >
                                        <td height="30" align="center" bgcolor="#FFFFFF"><div align="center">
                                          <table width="100%"  border="0">
                                            <tr>
                                              <td><span class="style4">Bulan :</span>
                                                <span class="style4">
                                                <select name="bulan"  id="bulan" onchange="showUser(this.value)">
                                                  <option>-- Pilih --</option>
                                                  <option value="1">Januari</option>
                                                  <option value="2">Februari</option>
                                                  <option value="3">Maret</option>
                                                  <option value="4">April</option>
                                                  <option value="5">Mei</option>
                                                  <option value="6">Juni</option>
                                                  <option value="7">Juli</option>
                                                  <option value="8">Agustus</option>
                                                  <option value="9">September</option>
                                                  <option value="10">Oktober</option>
                                                  <option value="11">November</option>
                                                  <option value="12">Desember</option>
                                                </select>
                                              </span></td>
                                              <td><span class="style4">Tahun :
                                                <select name="thn" id="select3" >
												 <option>-- Pilih --</option>
                                                      <?
		  echo "<option value=''>----</option>";
			$tahun=(integer) date ("Y");
			for ($ithn_u=$tahun; $ithn_u>($tahun-5); $ithn_u--){
				if ($ithn_u==$thn_u) echo "<option value=$ithn_u selected>$ithn_u";
				else echo "<option value=$ithn_u>$ithn_u";
			}echo "</option>"
		  ?>
                                              </select>
                                              </span></td>
                                            </tr>
                                          </table>
                                        </div>                                          <div id="txtHint"></div></td>
            </tr>
                                      <tr align="center">
                                        <td bgcolor="#FFFFFF"><div align="center">
                                            <input name="Submit" type="submit" class="csskuCopy" value="Lihat / Cetak">
											<input name="Keluar" type="button" id="Keluar" onClick="location='../../../../../menu_direktur2.php'" value="Keluar"/>
                                        </div></td>
                                      </tr>
                                  </table>
</form>
                                </tr>
                                <tr>
                                  <td>&nbsp;</td>
                                  <td>                                
                                  <td>&nbsp;</td>
                                </tr>
								  <form name="form2" method="get" action="../byr_dpst_thn.php" target="_blank">
								    <table width="450" height="50" border="2" align="center" cellpadding="3" cellspacing="3" bordercolor="#0099FF">
                                      <tr bordercolor="#0099FF" bgcolor="#FFFFFF">
                                        <td colspan="2" bordercolor="#0099FF" bgcolor="#0099FF"><div align="left" class="style6">
                                            <div align="center" class="style8 style1 style3">LAPORAN PEMBAYARAN MASUK TAHUNAN </div>
                                        </div></td>
                                      </tr>
                                    </table>
								    <table width="450" height="67" border="2" align="center" cellpadding="1" cellspacing="1" bordercolor="#0099FF">
			
			
					 
					
					
					 <tr >
					   <td width="198" align="center" bgcolor="#FFFFFF"><span class="style4">Pembayaran :</span>
                                                <span class="style4">
                       </span></td>
					   <td width="187" height="30" align="center" bgcolor="#FFFFFF"><div align="center" class="style4">Tahun :
                           <select name="thn"  id="thn">
                             <option>-- Pilih --</option>
                             <?
		  echo "<option value=''>----</option>";
			$tahun=(integer) date ("Y");
			for ($ithn_u=$tahun; $ithn_u>($tahun-5); $ithn_u--){
				if ($ithn_u==$thn_u) echo "<option value=$ithn_u selected>$ithn_u";
				else echo "<option value=$ithn_u>$ithn_u";
			}echo "</option>"
		  ?>
                         </select>
                                          
                       </div>					     <div id="txtHint"></div></td>
					   </tr>
                                      <tr align="center">
                                        <td height="30" colspan="2" bgcolor="#FFFFFF"><p>
                                          <input name="Submit" type="submit" class="csskuCopy" value="Lihat / Cetak">
										  <input name="Keluar" type="button" id="Keluar" onClick="location='../../../../../menu_direktur2.php'" value="Keluar"/>
                                        </p></td>
                                      </tr>
                                    </table>
								  </form>
                                  </div>
                                  </TD>
                                  </div>
                                  </div>
                                  </div>
                                  </div>
</body>
</html>
<?
}
else
{
 echo '<script language="javascript">window.alert("Anda belum Login.")</script>';
 echo '<meta http-equiv="Refresh" content="0; URL=../index.php">';;
}
?> 