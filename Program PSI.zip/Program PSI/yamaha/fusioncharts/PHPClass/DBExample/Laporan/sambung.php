<?

$lokasi = "localhost";
$user = "root";
$pass = "";
$dbname = "010112";

function db_connect()
{
  global $lokasi,$user,$pass,$dbname,$nyambung;
  $nyambung=mysql_connect($lokasi,$user,$pass) or die("Database tidak terhubung!");
  $db_select=mysql_select_db($dbname);
}
function closedb()
{
	global $nyambung;
	mysql_close($nyambung);
}

?>