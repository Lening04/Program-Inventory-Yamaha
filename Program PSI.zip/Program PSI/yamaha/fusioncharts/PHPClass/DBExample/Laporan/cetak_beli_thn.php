<?
session_start();
include "../sambung.php";
require_once ("../Master/tgl.php");
db_connect();

if ($_SESSION['Login'] == "true")
{/* $pegawai=$_SESSION['ID_PEGAWAI'];

$submit = $_POST[Tampilkan]; */

$thn=$_GET["thn"];
$bulan=$_GET["bulan"];
$tgl=$_GET["tgl"];
$tahun=$_GET["tahun"];
//-----HALAMAN----//
$num = $_GET['num'];//Get the numeration of the page 
	if(empty($num)){//if the numeration is empty 
		$num = 1;//the numeration is 1 
		$no = 1;
	}else{
		$no = 9*($num-1)+$num;
	} 
	$limit = 10;//Sets the limit of results to display in each page, change if you want. 
	$start = ($num-1)*$limit; 
	$start = round($start,0);//rounds the result 
	//lets make a loop and get all news from the database

	//$act = "cetak";
	db_connect();
	$sql1 = "SELECT p.TGL_PEMBELIAAN_DEPOSIT, p.ID_PEMBELIAAN_DEPOSIT, a.NAMA_AGEN, p.JUMLAH_PENAMBAHAN, p.STATUS_KIRIM_DEPOSIT
			 FROM pembeliaan_deposit p, agen a
			 WHERE (YEAR( p.TGL_PEMBELIAAN_DEPOSIT ) = '$thn') 
				AND a.ID_AGEN = p.ID_AGEN
			ORDER BY p.TGL_PEMBELIAAN_DEPOSIT ASC";	
	

	if (! $res1=@mysql_query($sql1))
	 {
	  echo "Data Kosong !";
	  return 0;
	 }
	 
	 switch ($bulan)
		{
			case 1: 
			$bln = "Januari"; 
			break;
			case 2: 
			$bln = "Februari"; 
			break;
		    case 3: 
			$bln = "Maret"; 
			break;
			case 4: 
			$bln = "April"; 
			break;
			case 5: 
			$bln = "Mei"; 
			break;
			case 6: 
			$bln = "Juni"; 
			break;
			case 7: 
			$bln = "Juli"; 
			break;
			case 8: 
			$bln = "Agustus"; 
			break;
		    case 9: 
			$bln = "September"; 
			break;
			case 10: 
			$bln = "Oktober"; 
			break;
			case 11: 
			$bln = "November"; 
			break;
			case 12: 
			$bln = "Desember"; 
			break;
		}
	
	$judul = "Laporan Pembayaran Masuk Tahun";

?>




<style type="text/css">
* {
  
}
.highslide-html {
    background:url(../obj/images/mainbg.gif);
}
.highslide-html-content {
	position: absolute;
    display: none;
}
.highslide-loading {
    display: block;
	color: black;
	font-size: 8pt;
	font-family: sans-serif;
	font-weight: bold;
    text-decoration: none;
	padding: 2px;
	border: 1px solid black;
    background-color: white;
}

.control {
	float: right;
    display: block;
    /*position: relative;*/
	margin: 0 5px;
	font-size: 9pt;
    font-weight: bold;
	text-decoration: none;
	text-transform: uppercase;
	color: #999;
}
.control:hover {
	color: black !important;
}
#tekslink
{
	text-decoration:none;
	color:#000000;
}
#tekslink:hover
{
	color: #0033FF;
}
.highslide-move {
    cursor: move;
}

.highslide-display-block {
    display: block;
}
.highslide-display-none {
    display: none;
}
</style>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>:: Laporan Penbeliaan Deposit Agen ::</title>
<link rel="shortcut icon" href="../images/lap.ico"/>

<style type="text/css">
.halaman {color:#000000; font-weight:bold; font-family:Arial, Helvetica, sans-serif; text-decoration:none; }
.style3 {color: #FFFFFF; font-weight: bold; font-family: Arial, Helvetica, sans-serif;}
.style4 {color: #FF3300; font-weight: bold; font-family: Arial, Helvetica, sans-serif;}
</style>

<!----------------- FORM - BUAT TOMBOL HEADER ----------------->
<style type="text/css">
<!--
#header
 {
	height:25px;
	background-color:#CCCCCC;
 }
#header:hover {background-color:#FF0000;}
.header1 
 {
 	font-family: Arial, Helvetica, sans-serif;
	text-decoration:none;
	font-weight:bold;
 }
.style11 {
	color: #000000;
	font-weight: bold;
}
.style12 {
	font-size: 18px;
	font-weight: bold;
	font-family: "Lucida Sans";
}
-->
</style>

</head>

<body>
<form id="form1" name="form1" method="post" action="">
  <table width="100" border="1" align="center" bordercolor="#000000">
    <tr>
      <td><table width="810" border="0" align="center">
  <tr>
    <td height="11" colspan="3" align="center" class="style11"><strong><br />
      PT. THERABUANA <br />
			Partner Travel Anda<br/>
			Jl. Kedung cowek 47 c, Suramadu, Surabaya<br />
			Telp : 031-3727777, 031-37287777<br />
    ----------------------------------------------------------------------------------------------------------------------------------------------------------------<br />
    </strong></td>
    </tr>
  <tr>
    <td width="147" height="41" align="center" class="style11">&nbsp;</td>
    <td width="510" align="center" class="style11"><div align="center"><?php echo $judul ?></div></td>
    <td width="139" align="right"><div id="tekslink"><a href="cetak_agen.php" id="tekslink"><span class="style4"><marquee behavior="alternate">Cetak Laporan</marquee></span></a></div></td>
  </tr>
</table>
<table width="810" border="1">
  <tr>
    <td><div align="center" class="style12">DAFTAR PEMBAYARAN </div></td>
  </tr>
  <tr>
    <td><table width="806" border="0" align="center">
    
    <tr>
      <td width="792"><table width="810" border="0" align="center" cellpadding="0" >
      </table>
        <table width="809" border="1" align="center" cellpadding="0" bordercolor="#000000" >
          <tr class="style3">
           <td width="34" height="27" bgcolor="#0099FF" ><div align="center">No</div></td>
            <td width="144" bgcolor="#0099FF"><div align="center">TGl Pembeliaan </div></td>
            <td width="119" bgcolor="#0099FF"><div align="center">No Pembeliaan</div></td>
            <td width="192" bgcolor="#0099FF"><div align="center">Franchisee</div></td>
			<td width="139" bgcolor="#0099FF"><div align="center">Status Pengiriman Deposit</div></td>
			<td width="153" bgcolor="#0099FF"><div align="center">Jumlah Pembeliaan</div></td>
          </tr>
          <tr>
            <?
			 $tot=0;		
			$jadwal=mysql_query("SELECT p.TGL_PEMBELIAAN_DEPOSIT, p.ID_PEMBELIAAN_DEPOSIT, a.NAMA_AGEN, 
			p.JUMLAH_PENAMBAHAN, p.STATUS_KIRIM_DEPOSIT
			 FROM pembeliaan_deposit p, agen a
			 WHERE (YEAR( p.TGL_PEMBELIAAN_DEPOSIT ) = '$thn') 
				AND a.ID_AGEN = p.ID_AGEN
			ORDER BY p.TGL_PEMBELIAAN_DEPOSIT ASC");
			
																					
        	while($j=mysql_fetch_array($jadwal)){
			$i++;
			$tr="#FFFFFF";
			if($i%2==0)$tr="#66FF00";		
			
			 //------Explode tanggal------//
			$tgl=$j['TGL_PEMBELIAAN_DEPOSIT'];
			$a=$j['TGL_PEMBELIAAN_DEPOSIT'];
			$d=explode("-",$a);
			$TGL_BELI=$d[2]."-".$d[1]."-".$d[0];	
																			
        	
		  ?>
		  	 <td height="24" align="center" bgcolor="<?=$tr?>"><?=$i?></td>
             <td bgcolor="<?=$tr?>" align="center"><?php echo $TGL_BELI; ?></td>
            <td bgcolor="<?=$tr?>" align="center"><?=$j[ID_PEMBELIAAN_DEPOSIT]?></td>
            <td bgcolor="<?=$tr?>" align="center"><?=$j[NAMA_AGEN]?></td>
			<? 
			 if ($j['STATUS_KIRIM_DEPOSIT']=="0")
				{$z="Belum Dikirim";}
		else
				{$z="Lunas";}
			?>	 
			<td bgcolor="<?=$tr?>" align="center"><?=$z?></td>
			<td bgcolor="<?=$tr?>" align="right">Rp. <?=number_format($j[JUMLAH_PENAMBAHAN],2,',','.')?></td>
          </tr>
		   <tr>
            <td height="2" colspan="8" bgcolor="#FFFF00"></td>
          </tr>
        <?
		//} 	
		?>
       <?php 
		//$no++;
		$tot=$tot + $j[JUMLAH_PENAMBAHAN];
		}	
		?>
          <?php
		  $tot=number_format($tot,2,',','.');
		echo"<tr bordercolor='#FFFFFF'><td colspan=5><div align='left'><b><font class='m1'>jumlah : </font></b></td>
		<td align='right'>Rp.$tot</td></tr>";	
		  $k=$no - 1;
			/*echo"<tr bordercolor='#FFFFFF'><td colspan=3><div align='left'><b><font class='m1'>Jumlah Franchisee : </font></b></td>
			<td colspan=10><div align='left'><b><font class='m1'>$k</font></b></td></tr>";*/
			$kyQuery = mysql_query("SELECT p.TGL_PEMBELIAAN_DEPOSIT, p.ID_PEMBELIAAN_DEPOSIT, a.NAMA_AGEN, 
			p.JUMLAH_PENAMBAHAN, p.STATUS_KIRIM_DEPOSIT
			 FROM pembeliaan_deposit p, agen a
			 WHERE (YEAR( p.TGL_PEMBELIAAN_DEPOSIT ) = '$thn') 
				AND a.ID_AGEN = p.ID_AGEN
			ORDER BY p.TGL_PEMBELIAAN_DEPOSIT ASC" );//Get the total number of results
			$totalpages = ceil(mysql_num_rows($kyQuery)/$limit);
			$c = 0;//The variable c is 0 
			echo "<br>";//make a <br> to separate the results from the [1][2]... 
			$kyQuery=mysql_query("SELECT p.TGL_PEMBELIAAN_DEPOSIT, p.ID_PEMBELIAAN_DEPOSIT, a.NAMA_AGEN, 
			p.JUMLAH_PENAMBAHAN, p.STATUS_KIRIM_DEPOSIT
			 FROM pembeliaan_deposit p, agen a
			 WHERE (YEAR( p.TGL_PEMBELIAAN_DEPOSIT ) = '$thn') 
				AND a.ID_AGEN = p.ID_AGEN
			ORDER BY p.TGL_PEMBELIAAN_DEPOSIT ASC LIMIT $start, $limit");
			echo"<tr bordercolor='#FFFFFF'><td colspan=15><div align='left'><b><font class='m1'>Halaman : </font></b>";
			while($c<$totalpages)
			{//while c is < than the total pages 
			$page = $c + 1;//sets the variable $page as 0 + 1 = 1 
			if($_GET['num']==$page)
			{//Gets the number of the page and if its the same that the page 
			echo "[$page] ";//its only echoes the page, not the url to this page  
			}
			else
			{//else 
			echo "<a href=cetak_beli_thn.php?num=$page>[$page] </a>";//it echoes the url to the page 
			} 
			$c =$c+1;
			} 
			echo"</div></td></tr>";
		
		?>
        </table></td>
    </tr>
  </table></td>
  </tr>
</table>
&nbsp;

</td>
    </tr>
  </table>
  
</form>
</body>
</html>
<?
}

	else
		{
		echo '<script language="javascript">window.alert("Anda belum Login.")</script>';
 echo '<meta http-equiv="Refresh" content="0; URL=index.php">';;
	}

?>