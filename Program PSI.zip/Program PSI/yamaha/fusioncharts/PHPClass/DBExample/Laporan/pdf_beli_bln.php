<?php
include"sambung.php";
 


db_connect();
	//$HARI = $_GET['HARI'];
$thn=$_GET["thn"];
$bulan=$_GET["bulan"];
$tgl=$_GET["tgl"];
$thn1=$_POST["thn"];
$bulan1=$_POST["bulan"];
$tgl1=$_POST["tgl"];

$query=mysql_query("SELECT p.TGL_PEMBELIAAN_DEPOSIT, p.ID_PEMBELIAAN_DEPOSIT, a.NAMA_AGEN, p.JUMLAH_PENAMBAHAN, p.STATUS_KIRIM_DEPOSIT
			 FROM pembeliaan_deposit p, agen a
			 WHERE (YEAR( p.TGL_PEMBELIAAN_DEPOSIT ) = '$thn') AND (MONTH( p.TGL_PEMBELIAAN_DEPOSIT ) = '$bulan')
				AND a.ID_AGEN = p.ID_AGEN
			ORDER BY p.TGL_PEMBELIAAN_DEPOSIT ASC");
								

 
  
  
define('FPDF_FONTPATH','fpdf/font/');
require('fpdf/fpdf_protection.php');

class PDF extends FPDF_Protection {
var $col=0;
var $y0;

	function Header() {
		$this->Cell(19,0.5, '','B',0,'C'); //garis
		$this->Ln(0.3);
	    $this->Image('../../../../../images/logo.jpg',1,2.3,3);
		$this->SetFont('courier','B',20);
		$this->SetTextColor(0,0,0);
		$this->Cell(22,2, 'PT. THERABUANA','0',0,'C');
		$this->Ln(0.8);
		$this->SetFont('courier','B',16);
		$this->Cell(22,2,'  Partner Travel Anda ',		'0',0,'C');
		$this->Ln(0.8);
		$this->SetFont('courier','B',14);
		$this->Cell(22,2,' Jl. Kedung cowek 47 c, Suramadu, Surabaya',		'0',0,'C');
		$this->Ln(0.8);
		$this->SetFont('courier','B',13);
		$this->Cell(22,2,'Telp : 031-3727777, 031-37287777',		'0',0,'C');
		$this->Ln(0.3);
		$this->Cell(19,1.5, '','B',0,'C'); //garis
		$this->Ln();
		$this->SetFont('courier','B',20);
		$this->SetTextColor(0,100,0);
		$this->Cell(19,2.5,' Laporan Penambahan Deposit AGen PerBulan ','0',0,'C');
		$this->Ln(2);
	}

	function Footer() {
		$this->SetY(-2);
		$this->Cell(19,0.5, '','B',0,'C'); //garis
		$this->SetY(-1.5);
		$this->SetFont('times','I',9);
		$this->Cell(0,1,'Halaman '.$this->PageNo().'/{nb}',0,0,'L');
		$y=date("Y");
		$d=date("d");
		$m=date("m");
		if($m=="01"){
		$b="Januari";}elseif($m=="02"){$b="Februari";}elseif($m=="03"){$b="Maret";}elseif($m=="04"){$b="April";
		}elseif($m=="05"){$b="Mei";}elseif($m=="06"){$b="Juni";}elseif($m=="07"){$b="Juli";}elseif($m=="08"){
		$b="Agustus";}elseif($m=="09"){$b="September";}elseif($m=="10"){$b="Oktober";}elseif($m=="11"){
		$b="Nopember";}else{$b="Desember";}
		$hari_ini="$d $b $y";	
		$this->SetFont('times','I',9);
		$this->Cell(0,1,'Tanggal Cetak : '.$hari_ini,0,0,'R');
	} 
}

$pdf=new PDF('P','cm','A4');
$pdf->SetProtection(array());
$pdf->Open();
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('courier','B',20);
$pdf->Ln(1);
$pdf->SetFont('times','B',11);
$pdf->SetFillcolor(230,230,230);
$pdf->SetTextcolor(0);
//$pdf->SetDrawcolor(128,0,0);
$pdf->Cell(1,0,'','0',0,'C');{
$pdf->Cell(1,1,'No','1',0,'C',1);
$pdf->Cell(2.5,1,'TGl Beli','1',0,'C',1);
$pdf->Cell(2.5,1,'No.Beli','1',0,'C',1);
$pdf->Cell(4,1,'Nama','1',0,'C',1);
$pdf->Cell(4,1,'Jumlah Beli Deposit','1',0,'C',1);
$pdf->Cell(4,1,'Status Pengiriman','1',0,'C',1);}
$pdf->Ln();
$pdf->SetFont('times','',11);
$i=1;
$totalpem=0;
while($get = mysql_fetch_array($query))
{
$pdf->Cell(1,0,'','0',0,'C');{
$pdf->Cell(1, 1, $i, 1, '0', 'C', $fill);
//------Explode tanggal------//
			$tgl=$get['TGL_PEMBELIAAN_DEPOSIT'];
			$a=$get['TGL_PEMBELIAAN_DEPOSIT'];
			$d=explode("-",$a);
			$TGL_PEMBELIAAN=$d[2]."-".$d[1]."-".$d[0];
$pdf->Cell(2.5, 1, $TGL_PEMBELIAAN, 1, '0', 'C', $fill);
$pdf->Cell(2.5, 1, $get[ID_PEMBELIAAN_DEPOSIT], 1, '0', 'L', $fill);
$pdf->Cell(4, 1, $get[NAMA_AGEN], 1, '0', 'C', $fill);

//===========STATUS KEANGGOTAAN=========//
			
			if($get[STATUS_KIRIM_DEPOSIT]=='1')
			{
				$aaa = "Terkirim" ;
			
			}
			elseif($get[STATUS_KIRIM_DEPOSIT]=='0')
			{
				$aaa = "Belum DIkirim" ;
						}
$pdf->Cell(4, 1, $aaa, 1, '0', 'L', $fill);
$totalpem = $totalpem + $get[JUMLAH_PENAMBAHAN];
$pdf->Cell(4, 1,number_format($get[JUMLAH_PENAMBAHAN],2,',','.'), 1, '0', 'C', $fill);
$pdf->Ln();
$i++;
$fill = !$fill;
}}
$pdf->Cell(1,0,'','0',0,'C');
$pdf->Cell(14,1,'Jumlah Total Pembelian',1,0,'C');
$pdf->SetFont('times','B',11);
//$tot=number_format($total,2,',','.');
$totalpem=number_format($totalpem,2,',','.');
$pdf->Cell(4,1,$totalpem,1,0,'C'); 
  $pdf->Output(); 
?> 