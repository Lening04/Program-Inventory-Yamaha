<?php
//We've included ../Includes/FusionCharts_Gen.php, which contains
//FusionCharts PHP Class to help us easily embed charts 
//We've also used ../Includes/DBConn.php to easily connect to a database.
include("../Includes/FusionCharts_Gen.php");
include("../Includes/DBConn.php");

?>
<HTML>
<HEAD>
<link rel="shortcut icon" href="../../../../images/grapik.png"/>
	<TITLE>
	Grafik Transaksi Agen
	</TITLE>
	<?php
	//You need to include the following JS file, if you intend to embed the chart using JavaScript.
	//Embedding using JavaScripts avoids the "Click to Activate..." issue in Internet Explorer
	//When you make your own charts, make sure that the path to this JS file is correct. Else, you would get JavaScript errors.
	?>	
	<SCRIPT LANGUAGE="Javascript" SRC="../../FusionCharts/FusionCharts.js"></SCRIPT>
	<style type="text/css">
	<!--
	body {
		font-family: Arial, Helvetica, sans-serif;
		font-size: 12px;
	}
	.text{
		font-family: Arial, Helvetica, sans-serif;
		font-size: 12px;
	}
	.ln{
		font-family:Verdana, Arial, Helvetica, sans-serif;
		font-size:12px;
		color:#FFFFFF;
		text-decoration:none;
	}
	#header
 	{
		height:40px;
		background-image:url(../../../../images/kembali.jpg);
		text-decoration:none;
 	}
	#header:hover {background-image:url(../../../../images/kembali.jpg);}
	-->
	</style>
</HEAD>
<BODY>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td height="20">&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>
<table width="156" border="0" align="center">
  <tr>
    <td width="150" height="25"><a href='javascript:history.go(-1);' id="header">
      <div id="header">
        <table height="25" border="0" cellpadding="0" cellspacing="0" align="center">
          <tr>
            <td align="center" valign="middle" class="header1"></td>
          </tr>
        </table>
      </div>
    </a> </td>
  </tr>
</table>
<br />
<CENTER>
  <p>
  <?php
	//In this example, we show how to connect FusionCharts to a database.
	//For the sake of ease, we've used an MySQL databases containing two
	//tables.
	$getThn = $_REQUEST['thn'];
	// Connect to the Database
	$link = connectToDB();

	# Create pie 3d chart object using FusionCharts PHP Class
 	$FC = new FusionCharts("Column3D","650","450"); 

	# Set Relative Path of swf file.
 	$FC->setSwfPath("../../FusionCharts/");
	
	//Store chart attributes in a variable for ease of use
	$strParam="caption=Grafik Data Total Transaksi AGen".$getThn."; xAxisName=Nama Agen; yAxisName=total Transaksi; yAxisMinValue=0; showBorder=1; showNames=1; formatNumberScale=0; numberPrefix= ; rotateNames=1; numberSuffix= ; decimalPrecision=0";
	
 	#  Set chart attributes
 	$FC->setChartParams($strParam);
	

	// Fetch all factory records usins SQL Query
	// Store chart data values in 'total' column/field and category names in 'FactoryName'
	// $strQuery = "select a.FactoryID, b.FactoryName, sum(a.Quantity) as total from Factory_output a, Factory_Master b where a.FactoryId=b.FactoryId group by a.FactoryId,b.FactoryName";
	//$strQuery = "select sum(a.TOTAL_RP) as total from penjualan a group by a.FactoryId,b.FactoryName";
	
	$strQuery = "SELECT count( t.ID_TRANSAKSI_AGEN ) transaksi, a.ID_AGEN,a.NAMA_AGEN, sum( t.TOTAL_TRANSAKSI ) AS total
				FROM agen a, transaksi_agen t
				WHERE a.ID_AGEN = t.ID_AGEN
				GROUP BY t.ID_AGEN";
	
	$result = mysql_query($strQuery) or die(mysql_error());
	//$f = mysql_fetch_array($strQuery);
	//$warna = $f["WARNA"];
	//Pass the SQL Query result to the FusionCharts PHP Class function 
	//along with field/column names that are storing chart values and corresponding category names
	//to set chart data from database
	if ($result) {
		$FC->addDataFromDatabase($result, "total", "NAMA_AGEN","","Laporan/pdf_eval_adgen.php?ID_AGEN=##ID_AGEN##");
	}
	mysql_close($link);

	# Render the chart
 	$FC->renderChart();
?>
<BR><BR>
</CENTER>
</BODY>
</HTML>