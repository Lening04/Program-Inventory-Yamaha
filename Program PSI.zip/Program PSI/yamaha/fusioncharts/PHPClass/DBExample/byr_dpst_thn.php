<?php
//We've included ../Includes/FusionCharts_Gen.php, which contains
//FusionCharts PHP Class to help us easily embed charts 
//We've also used ../Includes/DBConn.php to easily connect to a database.
include("../Includes/FusionCharts_Gen.php");
include("../Includes/DBConn.php");

?>
<HTML>
<HEAD>
<link rel="shortcut icon" href="../../../../images/grapik.png"/>
	<TITLE>
	Grafik Pembayaran Deposit Pertahun
	</TITLE>
	<?php
	//You need to include the following JS file, if you intend to embed the chart using JavaScript.
	//Embedding using JavaScripts avoids the "Click to Activate..." issue in Internet Explorer
	//When you make your own charts, make sure that the path to this JS file is correct. Else, you would get JavaScript errors.
	?>	
	<SCRIPT LANGUAGE="Javascript" SRC="../../FusionCharts/FusionCharts.js"></SCRIPT>
	<style type="text/css">
	<!--
	body {
		font-family: Arial, Helvetica, sans-serif;
		font-size: 12px;
	}
	.text{
		font-family: Arial, Helvetica, sans-serif;
		font-size: 12px;
	}
	.ln{
		font-family:Verdana, Arial, Helvetica, sans-serif;
		font-size:12px;
		color:#FFFFFF;
		text-decoration:none;
	}
	#header
 	{
		height:40px;
		background-image:url(../../../../images/kembali.jpg);
		text-decoration:none;
 	}
	#header:hover {background-image:url(../../../../images/kembali.jpg);}
	-->
	</style>
</HEAD>
<BODY>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td height="20">&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>
<table width="156" border="0" align="center">
  <tr>
    <td width="150" height="25"><a href='javascript:history.go(-1);' id="header">
      <div id="header">
        <table height="25" border="0" cellpadding="0" cellspacing="0" align="center">
          <tr>
            <td align="center" valign="middle" class="header1"></td>
          </tr>
        </table>
      </div>
    </a> </td>
  </tr>
</table>
<br />
<CENTER>
  <p>
  <?php
	//In this example, we show how to connect FusionCharts to a database.
	//For the sake of ease, we've used an MySQL databases containing two
	//tables.
	$getBln = $_GET['bulan'];
	$getThn = $_GET['thn'];

	
		if($getBln == '1')
	{ $nmbln = "Januari"; }
	elseif($getBln == '2')
	{ $nmbln = "Februari"; }
	elseif($getBln == '3')
	{ $nmbln = "Maret"; }
	elseif($getBln == '4')
	{ $nmbln = "April"; }
	elseif($getBln == '5')
	{ $nmbln = "Mei"; }
	elseif($getBln == '6')
	{ $nmbln = "Juni"; }
	elseif($getBln == '7')
	{ $nmbln = "Juli"; }
	elseif($getBln == '8')
	{ $nmbln = "Agustus"; }
	elseif($getBln == '9')
	{ $nmbln = "September"; }
	elseif($getBln == '10')
	{ $nmbln = "Oktober"; }
	elseif($getBln == '11')
	{ $nmbln = "November"; }
	else
	{ $nmbln = "Desember"; }
	// Connect to the Database
	$link = connectToDB();

	# Create pie 3d chart object using FusionCharts PHP Class
 	$FC = new FusionCharts("Column3D","650","450"); 

	# Set Relative Path of swf file.
 	$FC->setSwfPath("../../FusionCharts/");
	
	//Store chart attributes in a variable for ease of use
	$strParam="caption=Grafik Data Pembayaran Deposit Per TaHun ".$getThn."; xAxisName=BULAN Ke-; yAxisName=Total Pembayaran Deposit; yAxisMinValue=0; showBorder=1; showNames=1; formatNumberScale=0; numberPrefix= ; rotateNames=1; numberSuffix= ; decimalPrecision=0";
	
 	#  Set chart attributes
 	$FC->setChartParams($strParam);
	

	// Fetch all factory records usins SQL Query
	// Store chart data values in 'total' column/field and category names in 'FactoryName'
	// $strQuery = "select a.FactoryID, b.FactoryName, sum(a.Quantity) as total from Factory_output a, Factory_Master b where a.FactoryId=b.FactoryId group by a.FactoryId,b.FactoryName";
	//$strQuery = "select sum(a.TOTAL_RP) as total from penjualan a group by a.FactoryId,b.FactoryName";
	
	
	$strQuery = "SELECT SUM( r.BESAR_PEMBAYARAN ) AS BAYAR, (MONTH( r.TGL_PEMBAYARAN_DEPOSIT )) AS BULAN, 
	count( a.ID_AGEN ) AS JUMLAH
	FROM pembayaran_deposit r, agen a, pembeliaan_deposit p
	WHERE (YEAR( r.TGL_PEMBAYARAN_DEPOSIT ) = '$getThn') AND a.ID_AGEN = p.ID_AGEN
	AND r.ID_PEMBELIAAN_DEPOSIT = p.ID_PEMBELIAAN_DEPOSIT
	GROUP BY (MONTH( r.TGL_PEMBAYARAN_DEPOSIT ))";
	
	$result = mysql_query($strQuery) or die(mysql_error());
	//$f = mysql_fetch_array($strQuery);
	//$warna = $f["WARNA"];
	//Pass the SQL Query result to the FusionCharts PHP Class function 
	//along with field/column names that are storing chart values and corresponding category names
	//to set chart data from database
	if ($result) {
	
		$FC->addDataFromDatabase($result, "BAYAR", "BULAN" ,"","Laporan/pdf_byr_thn.php?BULAN=##BULAN##");
	}
	mysql_close($link);

	# Render the chart
 	$FC->renderChart();
?>
<BR><BR>
</CENTER>
</BODY>
</HTML>