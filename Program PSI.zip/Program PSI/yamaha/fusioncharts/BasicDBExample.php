<?php
//We've included ../Includes/FusionCharts.php and ../Includes/DBConn.php, which contains
//functions to help us easily embed the charts and connect to a database.
include("Includes/FusionCharts.php");
include("Includes/DBConn.php");
?>
<HTML>
   <HEAD>
      <TITLE>FusionCharts Free - Database Example</TITLE>
      <SCRIPT LANGUAGE="Javascript" SRC="js/FusionCharts.js"></SCRIPT>
   </HEAD>
   <BODY>
   <CENTER>
   <?php   
   //In this example, we show how to connect FusionCharts to a database.
   //For the sake of ease, we've used a MySQL database containing two
   //tables.

   //Connect to the DB
   $link = connectToDB();

   //$strXML will be used to store the entire XML document generated
   //Generate the graph element
   //$strXML = "<graph caption='Factory Output report' subCaption='Penjualan Per tahun' decimalPrecision='0' showNames='1' numberSuffix=' Rp' pieSliceDepth='30' formatNumberScale='0'>";
   $strXML = "<graph caption='Monthly Sales Summary' subcaption='For the year 2004' xAxisName='Month' yAxisMinValue='15000' yAxisName='Sales' decimalPrecision='0' formatNumberScale='0' numberPrefix='Rp ' showNames='1' showValues='0' showAlternateHGridColor='1' AlternateHGridColor='ff5904' divLineColor='ff5904' divLineAlpha='20' alternateHGridAlpha='5'>";

   //Fetch all factory records
   $strQuery = "select * from penjualan";
   
   
   $result = mysql_query($strQuery) or die(mysql_error());

   //Iterate through each factory
   if ($result) {
      while($ors = mysql_fetch_array($result)) {
         //Now create a second query to get details for this factory
         //$strQuery = "select sum(Quantity) as TotOutput from detail_penjualan where KODE_PENJ=" . $ors['KODE_PENJ'];
		 //$strQuery = "SELECT sum(`TOTAL_RP`)as total, month(`TANGGAL`)as bulan FROM `penjualan` group by `bulan` ";
		 $strQuery = "SELECT sum(TOTAL_RP) AS total, month(TANGGAL) AS bulan
					  FROM penjualan
					  GROUP BY bulan"   ;
		 
		 //$strQuery = "SELECT *  FROM `penjualan` where KODE_PENJ=" . $ors['KODE_PENJ'];
         $result2 = mysql_query($strQuery) or die(mysql_error());
         $ors2 = mysql_fetch_array($result2);
         //Generate <set name='..' value='..'/>
         //$strXML .= "<set name='" . $ors['KODE_BRG'] . "' value='" . $ors2['TotOutput'] . "' />";
		 //$strXML .= "<set name='" . $ors['TANGGAL'] . "' value='" . $ors2['TOTAL_RP'] . "'  />";
		 $strXML .= "<set name='" . $ors['bulan'] . "' value='" . $ors2['total'] . "'  />";
         //free the resultset hoverText='" . $ors3['TANGGAL'] . "'
         mysql_free_result($result2);
      }
   }
   mysql_close($link);

   //Finally, close <graph> element
   $strXML .= "</graph>";

   //Create the chart - Pie 3D Chart with data from $strXML
   echo renderChart("swf/FCF_Line.swf", "", $strXML, "FactorySum", 1650, 450);
?>
</BODY>
</HTML>