<?php
include ("koneksi1.php");

$option = $_REQUEST["option"];
$find = $_REQUEST["find"];
$ID_BARANG = $_REQUEST["ID_BARANG"];
$ID_TIPE = $_REQUEST["ID_TIPE"];
$NAMA_BARANG = $_REQUEST["NAMA_BARANG"];
$STOK_BARANG = $_REQUEST["STOK_BARANG"];
$STOK_KRITIS = $_REQUEST["STOK_KRITIS"];


switch ($option) {

case "insert" :
$sql = "insert into barang (ID_BARANG, ID_TIPE, NAMA_BARANG, STOK_BARANG)
values ('$_POST[ID_BARANG]','$_POST[ID_TIPE]','$_POST[NAMA_BARANG]','$_POST[STOK_BARANG]')";
break;

case "update" :
$sql = "update barang set ID_TIPE='$ID_TIPE', NAMA_BARANG='$NAMA_BARANG', STOK_BARANG='$STOK_BARANG'
where ID_BARANG ='$ID_BARANG' " ;
break;

case "delete" :
$sql = "delete from barang where ID_BARANG = '$ID_BARANG'";
break;
}

mysql_query($sql);

header("Location:baranginput.php");
?>