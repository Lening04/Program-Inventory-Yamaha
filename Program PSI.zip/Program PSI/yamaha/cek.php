<?php
session_start();

if (!isset($_SESSION['NIK']))
{
	echo "Anda belum login";
	exit;
	header("Location:index.html");
}

?>