<?php
include ("koneksi1.php");

$option = $_REQUEST["option"];
$find = $_REQUEST["find"];
$ID_DISKON = $_REQUEST["ID_DISKON"];
$DISKON = $_REQUEST["DISKON"];
$STATUS_DISKON = $_REQUEST["STATUS_DISKON"];


switch ($option) {

case "insert" :
$ubah=mysql_fetch_array(mysql_query("select * from diskon where STATUS_DISKON='0'"));
$st=$ubah['ID_DISKON'];
$non="update diskon set STATUS_DISKON='1' where ID_DISKON = '$st'";
mysql_query($non);
$sql = "insert into diskon(ID_DISKON, DISKON, STATUS_DISKON)
values ('$_POST[ID_DISKON]', '$_POST[DISKON]', '0')";
break;

case "update" :
$ubah=mysql_fetch_array(mysql_query("select * from diskon where STATUS_DISKON='0'"));
$st=$ubah['ID_DISKON'];
$non="update diskon set STATUS_DISKON='1' where ID_DISKON = '$st'";
mysql_query($non);
$sql = "update diskon set DISKON = '$DISKON', STATUS_DISKON='$STATUS_DISKON' where ID_DISKON = '$ID_DISKON' ";
break;

case "delete" :
$sql = "delete from diskon where ID_DISKON = '$ID_DISKON'";
break;
}


mysql_query($sql);

header("Location:diskon_input.php");
?>