<?php
include ("koneksi1.php");

$option = $_REQUEST["option"];
$find = $_REQUEST["find"];
$NAMA_BARANG = $_REQUEST["NAMA_BARANG"];
$ID_HARGA = $_REQUEST["ID_HARGA"];
$ID_BARANG = $_REQUEST["ID_BARANG"];
$TANGGAL = $_REQUEST["TANGGAL"];
$HARGA_JUAL = $_REQUEST["HARGA_JUAL"];
$HARGA_BELI = $_REQUEST["HARGA_BELI"];
$STATUS = $_REQUEST["STATUS"];



switch ($option) {

case "insert" : 
$sql = "insert into harga_barang (ID_HARGA, ID_BARANG, TANGGAL, HARGA_JUAL, HARGA_BELI, STATUS)
values ('$_POST[ID_HARGA]','$_POST[ID_BARANG]','$_POST[TANGGAL]','$_POST[HARGA_JUAL]','$_POST[HARGA_BELI]','$_POST[STATUS]')";
break;

case "update" :
$sql = "update harga_barang set TANGGAL='$TANGGAL', HARGA_JUAL='$HARGA_JUAL', HARGA_BELI='$HARGA_BELI', STATUS='$STATUS'
where ID_HARGA='$ID_HARGA'";
break;

case "delete" :
$sql = "delete from harga_barang where ID_HARGA = '$ID_HARGA'";
break;
}

mysql_query($sql);

header ("Location:hargaBarangInput.php");

?>