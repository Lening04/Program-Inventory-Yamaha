<?php 
include "koneksi1.php";
$IDBARANG = $_GET['q'];
if($IDBARANG){
    $query = mysql_query("select STOK_BARANG from barang where ID_BARANG='$IDBARANG'");
     $d = mysql_fetch_array($query);
     echo $d['STOK_BARANG'];
    
}
?>
