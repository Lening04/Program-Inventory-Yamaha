<?php
		include "cek.php";
		session_start();	
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Yamaha Kebon Agung Motor</title>
<meta name="keywords" content="blue, marble, design, theme, web, free templates, website templates, CSS, HTML" />
<meta name="description" content="Blue Marble Theme is a free website template provided by templatemo.com" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />


<link rel="stylesheet" href="nivo-slider.css" type="text/css" media="screen" />
<script src="js/jquery.min.js" type="text/javascript"></script>
<script src="js/jquery.nivo.slider.js" type="text/javascript"></script>

<script type="text/javascript">
$(window).load(function() {
	$('#slider').nivoSlider({
		effect:'random',
		slices:15,
		animSpeed:600,
		pauseTime:2400,
		startSlide:0, //Set starting Slide (0 index)
		directionNav:false, 
		directionNavHide:false, //Only show on hover
		controlNav:false, //1,2,3...
		controlNavThumbs:false, //Use thumbnails for Control Nav
		pauseOnHover:true, //Stop animation while hovering
		manualAdvance:false, //Force manual transitions
		captionOpacity:0.7, //Universal caption opacity
		beforeChange: function(){},
		afterChange: function(){},
		slideshowEnd: function(){} //Triggers after all slides have been shown
	});
});
</script>


<link type="text/css" href="js/css/le-frog/jquery-ui-1.8.18.custom.css" rel="stylesheet" />
<script type="text/javascript" src="js/jquery-1.7.1.min.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.8.18.custom.min.js"></script>
<script type="text/javascript">
$(function(){
			// Dialog			
				$('#dialog').dialog({
					autoOpen: false,
					width: 390,
					buttons: {
						"Ok": function(){
		    					$("#penjualan").submit();
		  						},
						"Cancel": function() { 
							$(this).dialog("close"); 
						} 
					}
				});			
				// Dialog Link
				$('#dialog_link').click(function(){
					$('#dialog').dialog('open');
					return false;
				});			
				//hover states on the static widgets
				$('#dialog_link, ul#icons li').hover(
					function() { $(this).addClass('ui-state-hover'); }, 
					function() { $(this).removeClass('ui-state-hover'); }
				);
				});
</script>



<style type="text/css">
<!--
.style3 {font-size: 16px}
body,td,th {
	color: #FFFFFF;
}
-->
</style>





</head>
<body>


<div id="templatemo_header_wrapper">
	<div id="templatemo_header">
    
    	<div id="site_title">
            <div align="left"><a href="http://www.templatemo.com"><span><strong>Part _and_ Accessories</strong></span></a> </div>
    	</div> <!-- end of site_title -->
    	<div id="social_box"> <a href="http://www.stumbleupon.com/" target="_blank"><img src="images/stumbleupon.png" alt="stumbleupon" /></a> <a href="http://digg.com/" target="_blank"><img src="images/digg.png" alt="digg" /></a> <a href="http://www.facebook.com/" target="_blank"><img src="images/facebook.png" alt="facebook" /></a> <a href="https://twitter.com/" target="_blank"><img src="images/twitter.png" alt="twitter" /></a> <a href="http://feeds.feedburner.com/BasicBlogTips" target="_blank"><img src="images/feed.png" alt="feed" /></a> </div>
  <div id="templatemo_menu">
            <ul>
                <li><a href="home.php" class="current">Home</a></li>
                
          </ul>    	
        </div> <!-- end of templatemo_menu -->
    
    </div> <!-- end of header -->
</div> <!-- end of header wrapper -->

<div id="templatemo_main_wrapper">
	<div id="templatemo_main">
    
    	<div id="templatemo_content">
        
        	<div id="homepage_slider">
                <div id="slider">
                    <a href="#"><img src="images/slideshow/01.jpg" alt="Image 1" title="Yamaha Kebon Agung Motor." /></a></div>
		  </div>
                	
        	<div class="post_box">
        		<a href="#"><img src="images/templatemo_image_01.jpg" alt="Image 1" /></a>
          <div class="post_box_right">
            <h2>Yamaha To Celebrate of 50 GP Racing</h2>
			<div class="post_meta"><strong>Date:</strong> May 28, 2011<a href="about.html"></a></div>
            <p>Race fans attending this year’s Motorcycle Live should definitely   schedule a stop at the Yamaha stand – the manufacturer will be   celebrating 50 years of Grand Prix road racing with a 415 square metre   display of machinery representing five decades on the track.</p>
            <div class="cleaner"></div>
                    		</div>
              <div class="cleaner">
                <ul class="tmo_list">
                  <div id="dialog" title="Jenis Customer">
                    <form action="penjualan.php" method="get" id="penjualan" name="penjualan">
                      <table width="351" border="0" align="center">
                        <tr>
                          <td width="170" align="left"><strong>Jenis Customer</strong></td>
                          <td width="171"><label>
                            <select name="jenis_customer" id="jenis_customer">
                              <option>-- Jenis Customer --</option>
                              <option value="0">yamaha</option>
                              <option value="1">individu</option>
                            </select>
                          </label></td>
                        </tr>
                      </table>
                    </form>
                  </div>
                </ul>
              </div>
            </div>
            
            </div>
    	<div id="templatemo_sidebar">
        	<div class="sidebar_box"><img src="images/templatemo_ads.png" width="259" height="250" /></div>  
        	
<div class="sidebar_box">
  <ul class="tmo_list">
  <?php
		include "cek.php";
		session_start();
			
						
if ($_SESSION['level'] == "OTO-001")		
{
     
      echo "<p>Selamat Datang ".$_SESSION['username']."</p>";?>
    </p>
    <p>&nbsp; </p>
    <blockquote>
      <p class="style3"><strong><a href="ubah_password.php">Ubah Password</a></strong></p>
      <p class="style3">&nbsp;</p>
      <p class="style3"><strong>Master</strong></p>
    </blockquote>
    <ul class="MenuBarVertical">
      <ul>
        <li><a href="karyawanInput.php">karyawan</a></li>
        <li><a href="baranginput.php">barang</a></li>
        <li><a href="tipeBarang_input.php">tipe barang</a></li>
        <li><a href="hargaBarangInput.php">harga barang</a></li>
        <li><a href="diskon_input.php">diskon</a></li>
        <li><a href="otoritasinput.php">otoritas</a></li>
      </ul>
    </ul>
    <blockquote>
      <p class="style3">&nbsp;</p>
    </blockquote>
    <h4><a href="logout.php" class="style2"><strong>Logout</strong></a></h4>
    <p>
      <?php		
}



else if ($_SESSION['level'] == "OTO-002")
  	 {
     //include ("stok_barang3.php");
      echo "<p>Selamat Datang ".$_SESSION['username']."</p>";?>
    </p>
    <p>&nbsp; </p>
    <blockquote>
      <p class="style3"><strong><a href="ubah_password.php">Ubah Password</a></strong></p>
      <p class="style3">&nbsp;</p>
      <p class="style3"><strong>Persetujuan</strong></p>
    </blockquote>
    <ul>
      <li><a href="acc_pemesanan.php">ACC pemesanan</a></li>
    </ul>
    <blockquote>
      <p class="style3">&nbsp;</p>
      <p class="style3"><strong>Inventori</strong></p>
      <ul>
        <li><a href="inventori.php">daftar suku cadang</a></li>
      </ul>
      <p class="style3">&nbsp;</p>
      <p class="style3"><strong>Laporan</strong></p>
    </blockquote>
                   <ul><ul><li><a href="lap_pemesanan.php">pemesanan</a></li>
                  <li><a href="lap_penerimaan.php">penerimaan</a></li>
                  <li><a href="lap_retur.php">retur</a></li>
                  <li><a href="lap_pnr_retur.php">penerimaan retur</a></li>
                  <li><a href="lap_penjualan.php">penjualan</a>                  </li>
                  <li><a href="lap_master_karyawan.php">Laporan Master Karyawan</a></li>
                  <li><a href="lap_master_hargaBarang.php">Laporan Master Harga Barang</a></li>
                  <li><a href="lap_master_Barang.php">Laporan Master Barang</a></li>
                  <li><a href="lap_master_tipeBarang.php">Laporan Master Tipe Barang</a></li>
		
          <blockquote>
            <p>&nbsp;</p>
          </blockquote>
        </li>
      </ul>
    </ul>
    <h4><a href="logout.php" class="style2"><strong> Logout</strong></a></h4>
    <p>
      <?php
		 
}
 


else if ($_SESSION['level'] == "OTO-004")//MARKETTING
{
      echo "<p>Selamat Datang ".$_SESSION['username']."</p>";?>
    </p>
    <blockquote>
      <blockquote>&nbsp;</blockquote>
      <p class="style3"><strong><a href="ubah_password.php">Ubah Password</a></strong></p>
      <p class="style3">&nbsp;</p>
      <p class="style3"><strong>Transaksi</strong></p>
      <ul>
        <li><a href="#" id="dialog_link">penjualan</a></li>
        <li><a href="his_penjualan.php">history penjualan</a></li>
      </ul>
      <p class="style3">&nbsp;</p>
    </blockquote>
    <h4><a href="logout.php" class="style2"><strong>Logout</strong></a></h4>
    <p>
      <?php
	   
}
else if ($_SESSION['level'] == "OTO-003") //PURCHASING
{
     include ("stok_barang.php");
      echo "<p>Selamat Datang ".$_SESSION['username']."</p>";?>
    </p>
    <blockquote>
      <blockquote>&nbsp;</blockquote>
      <p class="style3"><strong><a href="ubah_password.php">Ubah Password</a></strong></p>
      <p class="style3">&nbsp;</p>
      <p class="style3"><strong>Transaksi</strong></p>
      <ul>
        <li><a href="history_pemesanan.php">history pemesanan</a></li>
        <li><a href="pemesanan.php">pemesanan</a></li>
        <li><a href="penerimaan.php">penerimaan</a></li>
        <li><a href="display_retur.php">display retur</a></li>
        <li><a href="rtr_penerimaan.php">penerimaan retur</a></li>

      </ul>
      <p class="style3">&nbsp;</p>
    </blockquote>
    <h4><a href="logout.php" class="style2"><strong>Logout</strong></a></h4>
    <p>
      <?php
	   
}
	
	
	
?>
    </p>
</ul>
       	</div>
            
      </div>
        <div class="cleaner"></div>
    </div> <!-- end of main -->
</div> <!-- end of main wrapper -->


<div id="templatemo_footer_wrapper">
	<div id="templatemo_footer">    
        <p><center><strong>Copyright © 2016</strong><strong><br />
        Yamaha Kebon Agung Motor</strong><strong><br />
		</strong></center></p>
    </div>
	<div class="cleaner"></div>
</div> <!-- end of templatemo_footer -->


</body>
</html>
