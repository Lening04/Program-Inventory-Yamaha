<?php
//memasukkan data dari file data.php
include('exceltothego.php');
?>
<p><a href="export.php"><button>Export Data ke Excel</button></a></p>