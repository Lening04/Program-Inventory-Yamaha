<table border="1">
	<tr>
		<th>NO.</th>
		<th>ID BARANG</th>
		<th>ID TIPE</th>
		<th>NAMA BARANG</th>
		<th>STOK BARANG</th>
		<th>STOK KRITIS</th>
	</tr>
	<?php
	//koneksi ke database
include "koneksi1.php";
	
	//query menampilkan data
	$sql = mysql_query("SELECT * FROM barang ORDER BY ID_BARANG ASC");
	$no = 1;
	while($data = mysql_fetch_assoc($sql)){
		echo '
		<tr>
			<td>'.$no.'</td>
			<td>'.$data['ID_BARANG'].'</td>
			<td>'.$data['ID_TIPE'].'</td>
			<td>'.$data['NAMA_BARANG'].'</td>
			<td>'.$data['STOK_BARANG'].'</td>
			<td>'.$data['STOK_KRITIS'].'</td>
		</tr>
		';
		$no++;
	}
	?>
</table>