<?php
include"koneksi1.php";
include("FusionCharts.php");
include("FC_Colors.php");
?>


<HTML>
   <HEAD>
   <link rel="shortcut icon" href="index/untitled.bmp" type="image/x-icon" />
     <link rel="stylesheet" href= "../mburbee/Contents/Style.css" type="text/css"/>
      <SCRIPT LANGUAGE="Javascript" SRC="fusioncharts/FusionCharts/FusionCharts.js"></SCRIPT>
      <style type="text/css">
<!--
.style2 {
	font-family: Arial, Helvetica, sans-serif;
	font-size: x-small;
}
-->
      </style>
</HEAD>
   <BODY>
   <p>
   
   
<?php  
$tanggal = $_REQUEST["tanggal"];
$bulan = $_REQUEST["bulan"];
$tahun = $_REQUEST["tahun"];
$tanggal1 = $_REQUEST["tanggal1"];
$bulan1 = $_REQUEST["bulan1"];
$tahun1 = $_REQUEST["tahun1"];
		
$strXML = "<graph caption='GRAFIK RETUR SUKU CADANG PERIODE $tanggal-$bulan-$tahun SAMPAI $tanggal1-$bulan1-$tahun1' xAxisName='Barang' yAxisName='Jumlah Retur' decimalPrecision='0' showNames='1' numberSuffix=' ' pieSliceDepth='30' formatNumberScale='0'>";
  
$strQuery = "SELECT b.ID_BARANG 
FROM retur a, detail_retur b, karyawan c, barang d
WHERE a.NO_RETUR = b.NO_RETUR
AND a.NIK = c.NIK
AND b.ID_BARANG = d.ID_BARANG LIKE '$tahun-$bulan-$tanggal%'
AND a.TGL_RETUR >= '$tahun-$bulan-$tanggal'
AND a.TGL_RETUR <= '$tahun1-$bulan1-$tanggal1'
GROUP BY b.ID_BARANG";
   
   
   
$result = mysql_query($strQuery)or die(mysql_error());

if ($result) {
while($ors = mysql_fetch_array($result)) {
$jmlh=0;  
$b=$ors[ID_BARANG];
$nm = mysql_query("SELECT * FROM barang WHERE ID_BARANG='$b'");
$nama=mysql_fetch_array($nm);
$nama2=$nama['NAMA_BARANG'];
	  
$jum = mysql_query("SELECT b.* FROM retur a, detail_retur b WHERE a.NO_RETUR=b.NO_RETUR AND b.ID_BARANG='$b' 
AND (a.TGL_RETUR >= '$tahun-$bulan-$tanggal' 
and a.TGL_RETUR <='$tahun1-$bulan1-$tanggal1')");

while($jumlah = mysql_fetch_array($jum)){
$jmlh=$jmlh+$jumlah['JUMLAH_RETUR'];
}

$strXML .= "<set name='" . $nama2 . "' value='" . $jmlh . "' color='" .getFCColor() . "'/>";
        
}
}
  
$strXML .= "</graph>";
  
echo renderChart("fusioncharts/FusionCharts/FCF_Column3D.swf", "", $strXML, "FactorySum", 1250, 550);
 
?>


   </p>
   <p>&nbsp;</p>
   <?php echo $tanggal = $_REQUEST["tanggal"]; ?>
   <p>&nbsp;</p>
     </div>
   </div>
   </BODY>
</HTML>