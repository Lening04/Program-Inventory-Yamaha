<?php
session_start();
include ("koneksi1.php");
$NO_PES= $_REQUEST["NO_PES"];
$KETERANGAN=$_REQUEST["KETERANGAN"];

//update status acc ketika disetujui
if($_REQUEST['setuju']=='Setuju') 
{
$sql3="update pemesanan_barang set STATUS_ACC='1', KETERANGAN='$KETERANGAN' where NO_PEMESANAN='$NO_PES'";
mysql_query($sql3);
}

//update status acc ketika ditolak
if($_REQUEST['tolak']=='Tolak') 
{
$sql3="update pemesanan_barang set STATUS_ACC='3', KETERANGAN='$KETERANGAN' where NO_PEMESANAN='$NO_PES'";
mysql_query($sql3);
}

echo 'Data berhasil disimpan';
echo "<meta http-equiv=\"refresh\" content=\"1;url=acc_pemesanan.php\">";

?>