<?php
include ("koneksi1.php");	
$ID_TIPE = $_GET['ID_TIPE'];
$row = mysql_fetch_array(mysql_query("select * from tipe_barang where NAMA_TIPE='$ID_TIPE'"));
$id = $row['ID_TIPE'];

$barang = mysql_query("SELECT * FROM barang WHERE ID_TIPE='$id'");
echo "<option>-- Pilih Barang --</option>";
while($b = mysql_fetch_array($barang)){
?>
    <option value = "<?php echo $b[ID_BARANG]?>"> <?php echo $b[NAMA_BARANG]?> </option>
   
<?php
}
?>
