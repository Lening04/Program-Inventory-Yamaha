<?php
session_start(); 
$tes=$_SESSION['level'];
	
	if(!isset($_SESSION['username'])OR($_SESSION['password']))
		{
		echo "<meta http-equiv=\"refresh\" content=\"1;url=home.php\">";
		}		
	if ($_SESSION['level'] == "OTO-001")
   		{   
		echo "<p>Selamat Datang ".$_SESSION['username']."</p>";

include ("koneksi1.php");
include("kode_auto.php");
$option = $_REQUEST["option"];
$find = $_REQUEST["find"];
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Yamaha Kebon Agung Motor</title>
<meta name="keywords" content="blue, marble, design, theme, web, free templates, website templates, CSS, HTML" />
<meta name="description" content="Blue Marble Theme is a free website template provided by templatemo.com" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />


<script type="text/javascript"> 
	function validasi(){
		var text=document.forms["form1"]["DISKON"].value
		if(text==null || text=="" || text==0){
			alert("Diskon harus di isi !!!");
			return false;
		}	
   		
		var text=document.forms["form1"]["DISKON"].value
		pola_username=/^[0-9]{1,100}$/;
   		if (!pola_username.test(text)){
      		alert("Diskon harus di isi dengan angka !!!");
      		return false;
   		}
		
		var text=document.forms["form1"]["STATUS_DISKON"].value
		if(text=="-- Status --"){
			alert("Status diskon harus di isi !!!");
			return false;
		}	
	}
</script>

<script>
function confirmDelete(delUrl) {
  if (confirm("Apakah anda yakin untuk menghapus data ini ??")) {
    document.location = delUrl;
  }
}
</script>


<style type="text/css">
<!--
.style2 {	color: #FFFFFF;
	font-weight: bold;
}
.style3 {font-size: 16px}
.style18 {font-size: 13px}
.style22 {font-size: 14px; font-weight: bold; }
.style23 {font-weight: bold; font-size: 16px; color: #000000; }
.style24 {font-size: 14px}
-->
</style>
</head>
<body>

<div id="templatemo_header_wrapper">
	<div id="templatemo_header">
    
    	<div id="site_title">
            <a href="http://www.templatemo.com"><span><strong>Part _and_ Accessories</strong></span></a>        </div> 
<!-- end of site_title -->
<div id="social_box"> <a href="http://www.stumbleupon.com/" target="_blank"><img src="images/stumbleupon.png" alt="stumbleupon" /></a> <a href="http://digg.com/" target="_blank"><img src="images/digg.png" alt="digg" /></a> <a href="http://www.facebook.com/" target="_blank"><img src="images/facebook.png" alt="facebook" /></a> <a href="https://twitter.com/" target="_blank"><img src="images/twitter.png" alt="twitter" /></a> <a href="http://feeds.feedburner.com/BasicBlogTips" target="_blank"><img src="images/feed.png" alt="feed" /></a> </div>
<div id="templatemo_menu">
            <ul>
                <li><a href="home.php">Home</a></li>
            </ul>    	
      </div> <!-- end of templatemo_menu -->
    
    </div> <!-- end of header -->
</div> <!-- end of header wrapper -->

<div id="templatemo_main_wrapper">
	<div id="templatemo_main">
    
    	<div id="templatemo_content">
<div class="last_content_box">
        <h2></h2>
                <style type="text/css">
<!--
a:link {
	text-decoration: none;
	color: ##4f7eff;
}
a:visited {
	text-decoration: none;
	color: ##4f7eff;
}
a:hover {
	text-decoration: none;
}
a:active {
	text-decoration: none;
}
.style1 {font-weight: bold}
.style2 {color: #FF00FF}
-->
</style>
<h3 align="center" class="style2"><a href="diskon_input.php"><img src="images/table.png" width="100" height="107" /></a> <a href="diskon_input.php?option=update"><img src="images/new_data.png" width="94" height="100" /></a><a href="diskon_input.php?option=cari"><img src="images/search data.png" width="105" height="105" /></a></h3>
<p align="center">&nbsp;</p>


<?php		   
if($option =="")
{
$batasan=5;
$angka=$_GET['angka'];
$batas=$_GET[batas];
$halaman=$_GET['halaman'];
if(empty($halaman)){
	$posisi=0;
	$halaman=1;
}
else{
	$posisi = ($halaman-1)*$batas;
}
?>

<form action="<?php $file ?>" method="get">
<?php
echo"<input type=hidden name=halaman value=$halaman>
	 Tentukan Tampilan Data Per Halaman :";?>
	<select name=batas onchange="this.form.submit()">
<?php
//echo "<option value=$angka>";
for($j=1;$j<=6;$j++){
	$angka=$batasan*$j;?>	
    <?php
	if($batas==$angka)
		echo "<option value=$angka selected>$angka</option>";
		else
			echo "<option value=$angka>$angka</option>";}?>
</select>
</form>
</br>
<?php
if(empty($batas)){
	$batas=$batasan;}
else{
	$batas=$batas;
	
}		   
?>


<table width="550" border="1" align="center"  cellpadding="0" cellspacing="0">
<tr>
	<td width="31" bgcolor="#FFFF66"> <div align="center" class="style23">No</div> </td>
	<td width="111" bgcolor="#FFFF66"> <div align="center" class="style23">ID Diskon</div> </td>
	<td width="109" bgcolor="#FFFF66"> <div align="center" class="style23">Diskon</div> </td>
    <td width="171" bgcolor="#FFFF66"> <div align="center" class="style23">Status</div> </td>
	<td width="116" bgcolor="#FFFF66"> <div align="center" class="style23">Kontrol</div> </td>	
</tr>
<?php 
if(isset($find))
	{
	$sql2= "select *  from diskon where DISKON like '%$find%' ";
	}
else
	{
	$sql2= "select * from diskon ORDER BY ID_DISKON ASC LIMIT $posisi,$batas";
	}

$hasil = mysql_query($sql2);
$i=0+$posisi;

while($row=mysql_fetch_array($hasil)){
$i++;
?>

<tr>
	<td height="30" class="style18"> <div align="center" class="style24 style24"><?php echo $i; ?></div></td>
	<td class="style18"> <div align="center" class="style24 style24"><?php echo $row['ID_DISKON']; ?></div></td>
	<td class="style18"> <div align="center" class="style24 style24"><?php echo $row['DISKON']; ?> </div></td>
    <td class="style18"> <div align="center" class="style24 style24"><?php if($row['STATUS_DISKON']==0)
	{echo 'aktif';} else if($row['STATUS_DISKON']==1) {echo 'non aktif';} ?> </div></td>
	<td class="style18"><div align="center" class="style24 style24"><a href="diskon_input.php?option=update&ID_DISKON=<?php echo $row['ID_DISKON'];?>"><img src="images/edit-icon.png" width="39" height="36" /></a>|| <a href="diskon_proses.php?option=delete&ID_DISKON=<?php echo $row['ID_DISKON'];?>" onclick="return confirm('Apakah anda yakin untuk menghapus data ini ??')">
	  <img src="images/delete.png" width="32" height="35" /></a> </div></td>	
</tr>
<?php 
}
?>
</table>


<?php 
echo "<br>Halaman : ";
$tampil2 = mysql_query("select * from diskon");
$jmldata = mysql_num_rows ($tampil2);
$jmlhalaman = ceil($jmldata/$batas);
$file = "diskon_input.php";
for($k=1;$k<=$jmlhalaman;$k++)
if($k != $halaman){
	echo "<a href=$file?halaman=$k&batas=$batas>$k</a> | ";
}
else{
	echo "<b>$k</b> | ";
	}
echo "<p>Total jenis diskon : <b>$jmldata</b> jenis diskon</p>";
}
?>


<?php 
if($option=="cari"){
?>
<form id="form1" name="form1" method="post" action="diskon_input.php">
<table width="409" border="0" align="center">
  <tr>
    <td width="134"><span class="style22">Diskon</span></td>
    <td width="182"><label>
      <input type="text" name="find" id="find">
    </label></td>
    <td width="79"><label>
      <input type="submit" name="button2" id="button2" value="Search">
    </label></td>
  </tr>
</table>
</form>

<?php 
}



if($option=="update")
{
if(isset($_REQUEST["ID_DISKON"]))
{
$row = mysql_fetch_array(mysql_query("select * from diskon where ID_DISKON='".$_REQUEST["ID_DISKON"]."'"));
$ID_DISKON=$row[0]; $DISKON=$row[1];
$option = "update"; $readonly = "readonly=\"true\"";
}
else
{
$ID_DISKON ="";$DISKON="";
$option = "insert"; $readonly = "";
}
?> 
<form id="form1" name="form1" method="post" action="diskon_proses.php" onsubmit="return validasi()">

<table width="366" border="0" align="center">
  <tr>
    <td width="136"><span class="style22">ID Diskon</span></td>
    <td width="220"><label>
    <? 
		if($option=="insert"){ ?>
      		<input type="text" name="ID_DISKON" id="ID_DISKON" value="<?php echo kdauto ("diskon","DSK-")?>" disabled="disabled" />
      		<input type='hidden' name="ID_DISKON" id="ID_DISKON"  value="<? echo kdauto("diskon","DSK-"); ?>" /></label></td>
      <? } ?>
      <? 
	 	if($option=="update"){?> 
	  		<input type="text" name="ID_DISKON2" id="ID_DISKON2" value="<?php echo $ID_DISKON; ?>" disabled="disabled" />	
        	<input type="hidden" name="ID_DISKON" id="ID_DISKON" value="<?php echo $ID_DISKON; ?>"  />
      <? } 
	?>
</tr>
  <tr>
    <td><span class="style22">Diskon</span></td>
    <td><input type="text" name="DISKON" id="DISKON" value="<?php echo $DISKON; ?>"></td>
  </tr>
  <tr>
    <td><span class="style22">Status</span></td>
    <td>
    <p>
      <label></label>
      <label>
	<?php
    $id=$row[0]; 
    $data= mysql_fetch_array(mysql_query("select * from diskon where ID_DISKON='$id' "));
	$st=$data['STATUS_DISKON'];
	?>
    <select name="STATUS_DISKON" id="STATUS_DISKON">
    <?php
	if($row[2]=="")
	{
	?>
    <option>-- Status --</option>
    <option value="0">Aktif</option>
    <option value="1">Non aktif</option>
    <?php
	}
	else
	{
	if($st=="0"){
	?>
    <option value="0">Aktif</option>
    <option value="1">Non Aktif</option>
    <?php
	}else
	{?>
    <option value="1">Non aktif</option>
    <option value="0">Aktir</option>
    <?php
    }}
	?>
    </select>
      </label>
      <br />
    </p>      
      <label></label>
    </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><label>
   	  <input type="submit" name="button2" id="button2" value="Submit">
      <input type="reset" name="button3" id="button3" value="Cancel" onClick="self.history.back()">
      <input type="hidden" name="option" id="option" value="<?php echo $option;?>">
        
    </label></td>
  </tr>
</table>
</form> 





<?php 
}
?>




        <div class="service_box"></div>
                
          </div>
   	  </div> <!-- end of content -->
        
        <div id="templatemo_sidebar">
        	<div class="sidebar_box"><img src="images/templatemo_ads.png" width="250" height="250" /></div>  
        	
            <div class="sidebar_box">
              <ul class="tmo_list">
                <p>
                  <?php
		include "cek.php";
		session_start();
			
						
if ($_SESSION['level'] == "OTO-001")		
{
     
      echo "<p>Selamat Datang ".$_SESSION['username']."</p>";?>
                </p>
                <p>&nbsp; </p>
                <blockquote>
                  <p class="style3"><strong><a href="ubah_password.php">Ubah Password</a></strong></p>
                  <p class="style3">&nbsp;</p>
                  <p class="style3"><strong>Master</strong></p>
                </blockquote>
                <ul class="MenuBarVertical">
                  <ul>
                    <li><a href="karyawanInput.php">karyawan</a></li>
                    <li><a href="baranginput.php">barang</a></li>
                    <li><a href="tipeBarang_input.php">tipe barang</a></li>
                    <li><a href="hargaBarangInput.php">harga barang</a></li>
                    <li><a href="diskon_input.php">diskon</a></li>
                    <li><a href="otoritasinput.php">otoritas</a></li>
                  </ul>
                </ul>
                <blockquote>
                  <p class="style3">&nbsp;</p>
                </blockquote>
                <h4><a href="logout.php" class="style2"><strong>Logout</strong></a></h4>
                <p>
                  <?php		
}



else if ($_SESSION['level'] == "OTO-002")
  	 {
     
      echo "<p>Selamat Datang ".$_SESSION['username']."</p>";?>
                </p>
                <p>&nbsp; </p>
                <blockquote>
                  <p class="style3"><strong><a href="ubah_password.php">Ubah Password</a></strong></p>
                  <p class="style3">&nbsp;</p>
                  <p class="style3"><strong>Persetujuan</strong></p>
                </blockquote>
                <ul>
                  <li><a href="acc_pemesanan.php">ACC pemesanan</a></li>
                </ul>
                <blockquote>
                  <p class="style3">&nbsp;</p>
                  <p class="style3"><strong>Inventori</strong></p>
                  <ul>
                    <li><a href="inventori.php">daftar suku cadang</a></li>
                  </ul>
                  <p class="style3">&nbsp;</p>
                  <p class="style3"><strong>Laporan</strong></p>
                </blockquote>
                <ul>
                  <ul>
                    <li><a href="lap_pemesanan.php">pemesanan</a></li>
                    <li><a href="lap_penerimaan.php">penerimaan</a></li>
                    <li><a href="lap_retur.php">retur</a></li>
                    <li><a href="lap_pnr_retur.php">penerimaan retur</a></li>
                    <li><a href="lap_penjualan.php">penjualan</a>
                      <blockquote>
                        <p>&nbsp;</p>
                      </blockquote>
                    </li>
                  </ul>
                </ul>
                <h4><a href="logout.php" class="style2"><strong> Logout</strong></a></h4>
                <p>
                  <?php
		 
}



else if ($_SESSION['level'] == "OTO-003")
{
     
      echo "<p>Selamat Datang ".$_SESSION['username']."</p>";?>
                </p>
                <blockquote>
                  <blockquote>&nbsp;</blockquote>
                  <p class="style3"><strong><a href="ubah_password.php">Ubah Password</a></strong></p>
                  <p class="style3">&nbsp;</p>
                  <p class="style3"><strong>Transaksi</strong></p>
                  <ul>
                    <li><a href="history_pemesanan.php">history pemesanan</a></li>
                    <li><a href="pemesanan.php">pemesanan</a></li>
                    <li><a href="penerimaan.php">penerimaan</a></li>
                    <li><a href="display_retur.php">display retur</a></li>
                    <li><a href="rtr_penerimaan.php">penerimaan retur</a></li>
                    <li><a href="penjualan.php">penjualan</a></li>
                    <li><a href="his_penjualan.php">history penjualan</a></li>
                  </ul>
                  <p class="style3">&nbsp;</p>
                </blockquote>
                <h4><a href="logout.php" class="style2"><strong>Logout</strong></a></h4>
                <p>
                  <?php
	   
}
	
	
	
?>
                </p>
              </ul>
          </div>
      </div>
      <div class="cleaner"></div>
    </div> <!-- end of main -->
</div> <!-- end of main wrapper -->

<div id="templatemo_footer_wrapper">
	<div id="templatemo_footer">    
        <p><center><strong>Copyright © 2016</strong><strong><br />
        Yamaha Kebon Agung Motor</strong><strong><br />
		</strong></center></p>
    </div>
    
	<div class="cleaner"></div>
</div> <!-- end of templatemo_footer -->

</body>
</html>




<?php 
} 	  				
	else 
   		{
      		echo "<script>alert(' ANDA TIDAK MEMILIKI HAK AKSES');</script>";
	  		echo "<meta http-equiv=\"refresh\" content=\"1;url=home.php\">";
		}
?>